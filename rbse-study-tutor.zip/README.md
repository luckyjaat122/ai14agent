# RBSE Study Tutor - AI Personal Tutor for Class 12

Your AI elder brother who teaches RBSE Class 12 Science, Hindi & English like a personal tutor. Simple, fun, and effective learning.

## Features

- **5 AI Teacher Agents** - Biology, Physics, Chemistry, Hindi, English
- **PDF Knowledge System** - Upload textbooks, AI reads and teaches from them
- **30-Min Teaching Sessions** - Introduction → Concepts → Memory → Revision → Test
- **RAG Architecture** - LangChain + ChromaDB for intelligent retrieval
- **Doubt Solver** - "Samajh nahi aaya" → Simplified explanation
- **Flashcards** - Auto-generated with spaced repetition
- **Quiz System** - Easy, Medium, Board-level questions
- **Revision Notes** - One-page, Last-night, Important questions, Formula sheet

## Tech Stack

### Frontend
- Next.js 15 (App Router)
- React 19 + TypeScript
- Tailwind CSS + Framer Motion
- Clerk Authentication
- Zustand State Management
- React Markdown for rich content

### Backend
- FastAPI (Python)
- ChromaDB (Vector Database)
- PyPDF2 (PDF Processing)
- Sentence Transformers (Local Embeddings)
- Anthropic Claude API (AI Model)

## Project Structure

```
rbse-study-tutor/
├── frontend/           # Next.js application
│   ├── app/           # App router pages
│   │   ├── page.tsx           # Landing page
│   │   ├── dashboard/         # Student dashboard
│   │   ├── learn/            # Teaching interface
│   │   ├── quiz/             # Quiz system
│   │   ├── flashcards/       # Flashcards
│   │   ├── revision/         # Revision notes
│   │   └── doubt/            # Doubt solver
│   ├── components/   # Reusable components
│   ├── lib/           # Utilities, API, subjects data
│   ├── hooks/         # Zustand store
│   └── types/         # TypeScript types
│
├── backend/           # FastAPI application
│   ├── main.py        # Main API server
│   ├── requirements.txt
│   └── data/          # ChromaDB storage
│
└── README.md
```

## Quick Start

### 1. Clone and Setup

```bash
git clone <repo-url>
cd rbse-study-tutor
```

### 2. Frontend Setup

```bash
cd frontend
npm install
```

Create `.env.local`:
```env
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL=/dashboard
NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL=/dashboard
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
BACKEND_URL=http://localhost:8000
```

Run development server:
```bash
npm run dev
```

### 3. Backend Setup

```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Create `.env`:
```env
ANTHROPIC_API_KEY=sk-ant-api03-...
```

Run server:
```bash
python main.py
```

## Cost-Saving Features

1. **Local Embeddings** - Uses `sentence-transformers` instead of OpenAI API for embeddings
2. **Response Caching** - Caches Claude responses for 1 hour to avoid duplicate API calls
3. **Context Truncation** - Limits context to 2000 chars to reduce token usage
4. **Fallback Mode** - Works without Claude API using pre-built teaching templates
5. **Chunked Retrieval** - Only retrieves relevant chunks, never sends full PDF

## Teaching Methodology

### 30-Minute Session Structure

1. **Introduction (5 min)**
   - What is the chapter?
   - Why does it matter?
   - Real-world applications

2. **Concept Teaching (15 min)**
   - Simple Hindi explanation
   - English terms in brackets
   - Real-life examples
   - Stories and analogies
   - Diagram explanations
   - NCERT important lines

3. **Memory Mode (5 min)**
   - Mnemonics
   - Memory tricks
   - Cheat codes
   - Associations

4. **Revision (3 min)**
   - Key points
   - Important definitions
   - Formula sheet
   - Most important exam topics

5. **Testing (2 min)**
   - 5 easy questions
   - 5 medium questions
   - 5 board-level questions

### Agent Personalities

- **Biology**: Warm, patient, loves nature and farming
- **Physics**: Cool, practical, loves bikes and cricket
- **Chemistry**: Clever, kitchen experiment lover
- **Hindi**: Cultured, story and poetry lover
- **English**: Friendly, movie and song lover

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/chat` | POST | General chat/doubt solving |
| `/api/learn` | POST | Structured learning sessions |
| `/api/quiz/generate` | POST | Generate quiz questions |
| `/api/flashcards/generate` | POST | Generate flashcards |
| `/api/revision/generate` | POST | Generate revision notes |
| `/api/upload/pdf` | POST | Upload and process PDF |
| `/api/rag/retrieve` | POST | Retrieve relevant chunks |

## Customization

### Adding New Subjects

Edit `frontend/lib/subjects.ts`:
```typescript
export const SUBJECTS: Subject[] = [
  // Add your subject here
  {
    id: "new-subject",
    name: "New Subject",
    nameHindi: "नया विषय",
    color: "new-color",
    icon: "📚",
    description: "Description",
    totalChapters: 10,
    completedChapters: 0,
  },
]
```

### Customizing Agent Prompts

Edit `backend/main.py`:
```python
AGENT_PROMPTS = {
    "your-subject": """Your custom system prompt here...""",
}
```

## Deployment

### Vercel (Frontend)
```bash
cd frontend
vercel --prod
```

### Railway/Render (Backend)
```bash
cd backend
# Follow platform-specific instructions
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - Free for all students!

---

Made with ❤️ for every Class 12 student who dreams big.

**"Padhai se darr nahi lagta sahab, samajh nahi aata toh lagta hai"**
**- Ab samajh aayega! 🎯**
