# 🚀 RBSE Study Tutor - Complete Setup Guide

## Prerequisites

- Node.js 18+ 
- Python 3.9+
- Git

## Step 1: Get the Code

```bash
git clone <your-repo-url>
cd rbse-study-tutor
```

## Step 2: Setup Frontend (Next.js)

```bash
cd frontend

# Install dependencies
npm install

# Setup environment variables
cp .env.local.example .env.local

# Edit .env.local with your credentials:
# - Get Clerk keys from: https://dashboard.clerk.com
# - Get Supabase keys from: https://supabase.com
# - Backend URL: http://localhost:8000
```

**Required .env.local variables:**
```env
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL=/dashboard
NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL=/dashboard
BACKEND_URL=http://localhost:8000
```

## Step 3: Setup Backend (FastAPI)

```bash
cd backend

# Create virtual environment
python -m venv venv

# Activate (Linux/Mac)
source venv/bin/activate

# Activate (Windows)
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Setup environment variables
cp .env.example .env
```

**Required .env variables:**
```env
# Optional: Only if you want to use Claude API (costs money)
# Without this, app works FREE with fallback mode
ANTHROPIC_API_KEY=sk-ant-api03-...

# ChromaDB path
CHROMA_PERSIST_DIR=./data/chroma_db
```

## Step 4: Run the Application

**Terminal 1 - Backend:**
```bash
cd backend
source venv/bin/activate
python main.py
```
Backend runs at: http://localhost:8000

**Terminal 2 - Frontend:**
```bash
cd frontend
npm run dev
```
Frontend runs at: http://localhost:3000

## Step 5: Test Everything

1. Open http://localhost:3000
2. Sign up with Clerk
3. Select a subject (Biology, Physics, etc.)
4. Click "Learn" on any chapter
5. Chat with your AI Bhaiya!

## 💰 Cost-Saving Configuration (IMPORTANT!)

### FREE Mode (No Claude API needed)
The app works perfectly without Claude API! It uses:
- ✅ Pre-built teaching templates
- ✅ Local sentence-transformers for embeddings
- ✅ ChromaDB for vector storage
- ✅ In-memory response caching

### With Claude API (Better quality, costs money)
If you want higher quality responses:
1. Get API key from https://console.anthropic.com
2. Add to `backend/.env`: `ANTHROPIC_API_KEY=sk-ant-...`
3. Restart backend

**Estimated costs:**
- Without Claude: $0/month (FREE forever)
- With Claude: ~$5-20/month depending on usage

### Tips to minimize Claude costs:
1. Response caching enabled (avoids duplicate calls)
2. Context truncation (limits token usage)
3. Local embeddings (no OpenAI embedding costs)
4. Fallback mode (works without API)

## 📚 Uploading Your Textbooks

1. Go to Dashboard → Upload PDF
2. Select subject and upload PDF
3. System will:
   - Extract text
   - Detect chapters
   - Create chunks
   - Generate embeddings
   - Store in vector DB
4. AI will now teach from YOUR textbook!

## 🐛 Troubleshooting

### Frontend issues:
```bash
# Clear cache
rm -rf .next
rm -rf node_modules
npm install
npm run dev
```

### Backend issues:
```bash
# Reinstall dependencies
pip install -r requirements.txt --force-reinstall

# Check if running
 curl http://localhost:8000/
```

### ChromaDB issues:
```bash
# Delete and recreate
cd backend
rm -rf data/chroma_db
mkdir -p data/chroma_db
python main.py
```

## 🚀 Deployment

### Deploy Frontend (Vercel)
```bash
cd frontend
vercel --prod
```

### Deploy Backend (Railway/Render)
```bash
cd backend
# Follow platform-specific instructions
# Set environment variables in dashboard
```

### Docker Deployment
```bash
docker-compose up -d
```

## 📱 Features Checklist

- [x] Multi-agent architecture (5 subjects)
- [x] PDF upload and RAG
- [x] 30-minute teaching sessions
- [x] Doubt solver with simplification
- [x] Flashcards system
- [x] Quiz with 3 difficulty levels
- [x] Revision notes (4 types)
- [x] Hindi + English teaching
- [x] Cost-saving measures
- [x] Works without API keys (FREE mode)

## 🤝 Support

Having issues? 
1. Check the logs
2. Verify environment variables
3. Try the FREE mode first
4. Ask in the community

---

**Happy Learning! 📚🎓**
