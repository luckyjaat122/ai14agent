from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import os
import json
import hashlib
from datetime import datetime
import asyncio
from pathlib import Path

# ChromaDB for vector storage
import chromadb
from chromadb.config import Settings

# PDF processing
import PyPDF2
import io

# Local embeddings (FREE - saves Claude credits)
try:
    from sentence_transformers import SentenceTransformer
    LOCAL_EMBEDDINGS = True
    embed_model = SentenceTransformer('all-MiniLM-L6-v2')
    print("✅ Local embeddings loaded (FREE)")
except ImportError:
    LOCAL_EMBEDDINGS = False
    embed_model = None
    print("⚠️  sentence-transformers not installed. RAG will use fallback mode.")

# Claude API (only used when needed - cost saving)
try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False
    print("⚠️  anthropic not installed. Using fallback teaching mode.")

app = FastAPI(title="RBSE Study Tutor API", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Ensure data directory exists
Path("./data/chroma_db").mkdir(parents=True, exist_ok=True)

# Initialize ChromaDB
chroma_client = chromadb.Client(Settings(
    chroma_db_impl="duckdb+parquet",
    persist_directory="./data/chroma_db"
))

# Collections for each subject
subject_collections = {}
for subject in ["biology", "physics", "chemistry", "hindi", "english"]:
    subject_collections[subject] = chroma_client.get_or_create_collection(
        name=f"rbse_{subject}",
        metadata={"subject": subject}
    )

# In-memory cache for Claude responses (cost saving - avoids duplicate API calls)
response_cache: Dict[str, Dict[str, Any]] = {}
CACHE_TTL = 3600  # 1 hour

# Claude client (lazy initialization)
claude_client = None

def get_claude_client():
    global claude_client
    if claude_client is None and ANTHROPIC_AVAILABLE:
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if api_key:
            claude_client = anthropic.Anthropic(api_key=api_key)
    return claude_client

# ============================================
# AGENT SYSTEM PROMPTS (5 Specialized Teachers)
# ============================================

AGENT_PROMPTS = {
    "biology": """You are Bhaiya, a caring elder brother teaching Biology to a weak Class 12 RBSE student. You teach like you're sitting next to him.

CRITICAL RULES:
1. Always explain in SIMPLE HINDI first, then English terms in brackets
2. Use daily life examples - body, farming, food, family
3. For every concept: give a story or analogy first
4. Explain diagrams in detail - describe what each part does
5. Highlight NCERT important lines with > quotes
6. Break down scientific words: "Mitochondria = mito (thread) + chondria (granule)"
7. After every concept ask: "Samajh aaya ya aur simple example doon?"
8. Never assume prior knowledge - teach from ZERO
9. Use emojis to make it fun
10. Keep sentences short. Max 15 words per sentence.

TEACHING SEQUENCE:
1. Real-life hook (2 min)
2. Concept explanation with analogy (5 min)
3. Diagram description (3 min)
4. NCERT important lines (2 min)
5. Memory trick (1 min)
6. Check understanding (1 min)

COST SAVING: Be concise but complete. Use bullet points. One concept at a time.""",

    "physics": """You are Bhaiya, a cool elder brother teaching Physics to a weak Class 12 RBSE student. You make physics feel like everyday magic.

CRITICAL RULE - NEVER START WITH FORMULA:
1. Start with bike/cricket/mobile/fan/train example
2. Ask "Kabhi notice kiya?"
3. Explain what happens and WHY
4. Draw mental picture
5. THEN give formula
6. Solve with numbers from daily life

LANGUAGE:
- Simple Hindi first, English terms in brackets
- "Electric field matlab woh zameen jahan charge paida hota hai"
- Break formulas: "F = qE matlab Force = charge x Electric field"

ENGAGEMENT:
- After every concept: "Samajh aaya? Cricket me kaise hota hai ye?"
- Use emojis
- Make student feel smart: "Tu already ye janta hai, bas formal name sikhna hai"

COST SAVING: Be concise. One concept per response. Use bullet points.""",

    "chemistry": """You are Bhaiya, a clever elder brother teaching Chemistry to a weak Class 12 RBSE student using kitchen and daily life analogies.

TEACHING METHOD:
1. Every reaction = Cooking recipe
   - Reactants = Ingredients
   - Conditions = Temperature/Gas
   - Products = Final dish
   - Catalyst = Mom's magic touch

2. Step-by-step mechanisms:
   - Arrow pushing = "Ye electron idhar gaya"
   - Intermediates = "Beech ka maal"
   - Final product = "Final dish ready"

3. Numericals:
   - Pehle formula likh
   - Values rakh
   - Step-by-step solve
   - Units check karo

4. Memory shortcuts for EVERYTHING:
   - OIL RIG, LEO GER, AN OX RED CAT
   - Create new ones on the spot

LANGUAGE: Hindi + English terms
COST SAVING: Be concise, use emojis, make it fun!""",

    "hindi": """You are Bhaiya, a cultured elder brother teaching Hindi to a Class 12 RBSE student. You love stories and explain deep meanings simply.

TEACHING STYLE:
1. Line-by-line explanation:
   - Pehle shabdo ka arth (word meaning)
   - Phir vakya ka arth (sentence meaning)
   - Phir chhupa hua arth (hidden meaning)
   - Phir lekhak ka intention (writer's message)

2. For Poetry:
   - Pehle padhao (make student read)
   - Phir explain karo line by line
   - Bhav (emotion) samjhao
   - Alankar identify karo
   - Life se connect karo

3. For Grammar:
   - Rule simple words me
   - 3 examples immediately
   - Common mistakes batayo
   - Practice karwao

4. For Writing:
   - Format dikhao
   - Sample likhke do
   - Important phrases do
   - Practice topics do

COST SAVING: Be concise. Use examples. One topic at a time.""",

    "english": """You are Bhaiya, a friendly elder brother teaching English to a Class 12 RBSE student. You compare literature to movies and real life.

TEACHING SEQUENCE:
1. Story summary (like Netflix recap):
   - "Ye story hai ek ladke ki..."
   - 2-3 minute summary in Hindi
   - "Jaise movie me hota hai..."

2. Characters (like real people):
   - Name + personality + role
   - "Ye character jaise aapka dost hai jo..."
   - Character map banao

3. Vocabulary:
   - Difficult words list
   - Hindi meaning
   - Sentence me use karo
   - Daily life me kaise use hoga

4. Important questions:
   - Board ke perspective se
   - Answer format batao
   - Key points highlight karo
   - Practice karwao

5. Grammar:
   - Rule simple Hindi me
   - Error spot karwao
   - Transformation practice

COST SAVING: Be concise. Use comparisons. One lesson at a time.""",
}

# ============================================
# DATA MODELS
# ============================================

class ChatRequest(BaseModel):
    message: str
    subjectId: str
    chapterId: Optional[str] = None
    sessionId: Optional[str] = None
    context: Optional[str] = None
    isDoubt: bool = False
    simplifyLevel: int = 0
    ragChunks: Optional[List[Dict[str, Any]]] = None

class LearnRequest(BaseModel):
    subjectId: str
    chapterId: str
    part: str
    previousMessages: Optional[List[Dict[str, str]]] = None
    conceptIndex: Optional[int] = None

class QuizRequest(BaseModel):
    subjectId: str
    chapterId: str
    difficulty: str = "mixed"
    count: int = 15

class FlashcardRequest(BaseModel):
    subjectId: str
    chapterId: str
    count: int = 20

class RevisionRequest(BaseModel):
    subjectId: str
    chapterId: str
    type: str

class RAGRequest(BaseModel):
    query: str
    subjectId: str
    chapterId: Optional[str] = None
    topK: int = 5

# ============================================
# HELPER FUNCTIONS
# ============================================

def get_cache_key(data: dict) -> str:
    """Generate cache key from request data"""
    key_str = json.dumps(data, sort_keys=True)
    return hashlib.md5(key_str.encode()).hexdigest()

def get_cached_response(cache_key: str) -> Optional[str]:
    """Get cached response if valid"""
    if cache_key in response_cache:
        entry = response_cache[cache_key]
        if (datetime.now() - entry["timestamp"]).seconds < CACHE_TTL:
            return entry["response"]
    return None

def cache_response(cache_key: str, response: str):
    """Cache a response to save API costs"""
    response_cache[cache_key] = {
        "response": response,
        "timestamp": datetime.now()
    }

def get_embedding(text: str) -> Optional[List[float]]:
    """Get embedding - uses FREE local model instead of paid API"""
    if LOCAL_EMBEDDINGS and embed_model:
        return embed_model.encode(text).tolist()
    return None

def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50) -> List[str]:
    """Split text into overlapping chunks for RAG"""
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end]
        if len(chunk.strip()) > 50:  # Only keep substantial chunks
            chunks.append(chunk.strip())
        start = end - overlap
    return chunks

def extract_text_from_pdf(file_bytes: bytes) -> str:
    """Extract text from PDF using PyPDF2"""
    try:
        pdf_reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
        text = ""
        for page in pdf_reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
        return text
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"PDF extraction failed: {str(e)}")

def detect_chapters(text: str) -> List[str]:
    """Detect chapter titles from PDF text"""
    patterns = [
        r'Chapter\s+\d+[\s:\-\.]+([^
]+)',
        r'\d+\.[\s]+([A-Z][^
]{10,})',
        r'\d+[\s]+([A-Z][^
]{15,})',
        r'अध्याय\s+\d+[\s:\-\.]+([^
]+)',
    ]
    chapters = []
    for pattern in patterns:
        matches = re.findall(pattern, text)
        for match in matches:
            clean = match.strip()
            if len(clean) > 5 and clean not in chapters:
                chapters.append(clean)
    return chapters[:20] if chapters else ["Chapter 1", "Chapter 2", "Chapter 3"]

def format_teaching_response(content: str, subject_id: str, part: str) -> Dict[str, Any]:
    """Format teaching response with Hindi/English split"""
    # Try to split into Hindi and English sections
    if "---HINDI---" in content:
        parts = content.split("---HINDI---")
        english = parts[0].strip()
        hindi = parts[1].strip()
    else:
        english = content.strip()
        hindi = ""

    return {
        "message": english,
        "messageHindi": hindi,
        "type": part,
        "ragUsed": False,
    }

async def call_claude_api(system_prompt: str, user_message: str, max_tokens: int = 1500) -> str:
    """Call Claude API with cost-saving measures"""
    client = get_claude_client()
    if not client:
        return None

    try:
        response = client.messages.create(
            model="claude-3-sonnet-20240229",  # Cheaper than Opus
            max_tokens=max_tokens,
            system=system_prompt,
            messages=[{"role": "user", "content": user_message}]
        )
        return response.content[0].text
    except Exception as e:
        print(f"Claude API error: {e}")
        return None

# ============================================
# FALLBACK RESPONSE GENERATORS (Zero API Cost)
# ============================================

def generate_fallback_chat(message: str, subject_id: str, chapter_id: Optional[str], is_doubt: bool, rag_context: str = "") -> str:
    """Generate chat response WITHOUT using Claude API - saves credits!"""

    if is_doubt:
        return f"""Arre koi baat nahi bhai! 😊

Main **aur bhi simple** samjhata hoon...

**Aur Simple Version:**

Socho jaise ghar me **{subject_id}** ka example...

**Step-by-step:**
1. Pehle ye samjho - basic idea
2. Phir detail me jao
3. Bas ho gaya!

**Key Point:**
- Ye concept bas itna hai
- Daily life se jodo
- Diagram banao dimaag me

Ab samajh aaya? Nahi aaya toh aur simple bataunga! 👍

*Pro tip: Rote mat, samajh ke yaad karo!*"""

    return f"""Badiya sawal! 🤔

**{message[:100]} ka jawab:**

**Simple me:**
Ye concept aise samjho - jaise {subject_id} me hota hai...

**Example:**
Socho daily life se...

**Important Points:**
- Point 1: Basic definition
- Point 2: Key concept  
- Point 3: Application

{rag_context[:200] if rag_context else ""}

**NCERT Line:**
> "Important line from NCERT textbook"

Samajh aaya? "Samajh nahi aaya" likh do toh aur simple bataunga! 👇"""

def generate_fallback_learn(request: LearnRequest) -> str:
    """Generate learning content WITHOUT using Claude API"""

    part = request.part
    chapter = request.chapterId

    if part == "introduction":
        return f"""## 🎯 Chapter Introduction

**Kya hai ye chapter?**
Ye chapter {chapter} ke baare me hai. Basic concept se shuru karte hain.

**Kyun padhna hai?**
- Board exam me 8-10 marks ka aata hai
- Real life me bahut kaam aata hai
- Aage ke chapters ka base hai

**Real-life Application:**
Socho jaise roz subah uthte ho - wahi process is chapter me hai! 😊

**Taiyaar ho?**
"Concepts" button pe click karo - ab asli padhai shuru! 🚀

---HINDI---
## 🎯 अध्याय परिचय

**यह अध्याय क्या है?**
यह अध्याय {chapter} के बारे में है। बुनियादी अवधारणा से शुरू करते हैं।

**क्यों पढ़ना है?**
- बोर्ड परीक्षा में 8-10 नंबर का आता है
- वास्तविक जीवन में बहुत काम आता है"""

    elif part == "concept":
        return f"""## 🧠 Concept Teaching

**Topic 1: Basic Concept**

Simple words me - ye concept aise samjho...

*Analogy:*
Jaise ghar me... (daily life example)

**Key Points:**
1. Point 1 - definition
2. Point 2 - explanation
3. Point 3 - example

**Diagram Description:**
Imagine karo - beech me ye part hai, left side ye hai...

**NCERT Important Line:**
> "Ye line NCERT se hai - isko yaad rakhna"

**Formula (if any):**
```
F = ma
```

Samajh aaya? Nahi aaya toh "Samajh nahi aaya" likh do! 👇

---HINDI---
## 🧠 अवधारणा शिक्षण

**विषय 1: बुनियादी अवधारणा**

सरल शब्दों में - इस अवधारणा को ऐसे समझो..."""

    elif part == "memory":
        return f"""## ✨ Memory Mode

**Mnemonic:**
"MRS GREN - Movement, Respiration, Sensitivity, Growth, Reproduction, Excretion, Nutrition"

**Memory Trick:**
- Pehla letter: **K**eep **P**ond **C**lean **O**r **F**rogs **G**et **S**ick
- Yaad rahega? Funny hai na! 😄

**Cheat Code:**
Exam me bas ye yaad rakhna:
1. Formula 1
2. Definition 2
3. Diagram 3

**Association:**
Is concept ko apni life se jodo...

Ab test ke liye taiyaar? 🎯

---HINDI---
## ✨ याद रखने का तरीका

**मेमोनिक:**
"MRS GREN - गति, श्वसन, संवेदनशीलता, वृद्धि, प्रजनन, उत्सर्जन, पोषण"""

    elif part == "revision":
        return f"""## 📝 Quick Revision

**Key Points (2 minute me):**
1. Main concept summary
2. Important definition
3. Key formula

**Formula Sheet:**
```
F = ma
E = mc²
```

**Most Important for Board:**
- 5 marks question: Explain with diagram
- 3 marks question: Definition + example
- 1 mark question: Fill in the blank

**Last Night Tips:**
- Diagrams practice karo
- Formulas ratt lo
- Definitions exact words me yaad karo

Ab TEST! ⚡

---HINDI---
## 📝 त्वरित पुनरावृत्ति

**मुख्य बिंदु (2 मिनट में):**
1. मुख्य अवधारणा सारांश
2. महत्वपूर्ण परिभाषा
3. मुख्य सूत्र"""

    else:  # testing
        return f"""## ⚡ Test Yourself

**5 Easy Questions (1 mark each):**
1. Define {chapter}.
2. What is the basic unit?
3. Name one example.
4. True or False: ...
5. Fill in the blank: ...

**5 Medium Questions (2 marks each):**
6. Explain with example.
7. Differentiate between A and B.
8. Draw a labeled diagram.
9. Write two features.
10. What happens when...?

**5 Board Level (3-5 marks each):**
11. Explain in detail with diagram.
12. Describe the process step-by-step.
13. Compare and contrast.
14. Application-based question.
15. NCERT exercise question.

Answer do neeche! Main check karunga! ✅

---HINDI---
## ⚡ अपनी जांच करें

**5 आसान सवाल (1 नंबर each):**
1. {chapter} की परिभाषा दें।"""

# ============================================
# API ENDPOINTS
# ============================================

@app.get("/")
async def root():
    return {
        "message": "RBSE Study Tutor API",
        "version": "2.0.0",
        "status": "running",
        "features": {
            "claude_api": ANTHROPIC_AVAILABLE and bool(os.getenv("ANTHROPIC_API_KEY")),
            "local_embeddings": LOCAL_EMBEDDINGS,
            "rag": True,
            "cache": True,
        }
    }

@app.post("/api/chat")
async def chat(request: ChatRequest):
    """Handle chat messages with cost-saving: cache + fallback mode"""

    # Check cache first (saves API cost!)
    cache_key = get_cache_key(request.dict(exclude={"sessionId"}))
    cached = get_cached_response(cache_key)
    if cached:
        return {
            "message": cached,
            "messageHindi": "",
            "type": "doubt" if request.isDoubt else "general",
            "ragUsed": False,
            "cached": True,
        }

    # Get RAG context (FREE - uses local embeddings)
    rag_context = ""
    if request.ragChunks:
        rag_context = "\n\n".join([chunk["text"] for chunk in request.ragChunks[:3]])
    else:
        # Try to retrieve from vector DB
        try:
            collection = subject_collections.get(request.subjectId, subject_collections["biology"])
            embedding = get_embedding(request.message)
            if embedding:
                results = collection.query(
                    query_embeddings=[embedding],
                    n_results=3
                )
                if results and results["documents"]:
                    rag_context = "\n".join(results["documents"][0])
        except Exception as e:
            print(f"RAG retrieval error: {e}")

    # Build system prompt
    system_prompt = AGENT_PROMPTS.get(request.subjectId, AGENT_PROMPTS["biology"])
    if request.isDoubt:
        system_prompt += "\n\nThe student is confused. Simplify the explanation even more. Use the simplest possible analogy. Break it into 3 steps. Ask if they understood."

    # Cost-saving: Truncate context
    context = request.context or ""
    if len(context) > 2000:
        context = context[-2000:]

    # Try Claude API first (if available and configured)
    claude_response = None
    if ANTHROPIC_AVAILABLE and os.getenv("ANTHROPIC_API_KEY"):
        user_prompt = f"""Student message: {request.message}

Context: {context}

RAG Context: {rag_context[:500]}

Respond as Bhaiya (elder brother tutor). Use simple Hindi + English."""

        claude_response = await call_claude_api(system_prompt, user_prompt, max_tokens=1200)

    # Use Claude response if available, else fallback (FREE)
    if claude_response:
        response_text = claude_response
    else:
        response_text = generate_fallback_chat(
            request.message, 
            request.subjectId, 
            request.chapterId,
            request.isDoubt,
            rag_context
        )

    # Cache the response (saves future API calls!)
    cache_response(cache_key, response_text)

    return {
        "message": response_text,
        "messageHindi": "",
        "type": "doubt" if request.isDoubt else "general",
        "ragUsed": bool(rag_context),
        "cached": False,
        "apiUsed": claude_response is not None,
    }

@app.post("/api/learn")
async def learn(request: LearnRequest):
    """Handle structured learning sessions with 5 parts"""

    part_prompts = {
        "introduction": "Give a 5-minute introduction. What is this chapter? Why study it? Real-life applications? Use simple Hindi. Make it exciting!",
        "concept": "Teach the core concepts. Use analogies, stories, examples. Break down difficult words. Explain diagrams. Never assume prior knowledge.",
        "memory": "Create mnemonics, memory tricks, cheat codes. Help the student remember everything for the exam. Make it funny and memorable.",
        "revision": "Give key points, important definitions, formula sheet. Most important exam topics. One-page summary style.",
        "testing": "Generate 5 easy + 5 medium + 5 board-level questions. Evaluate answers. If wrong, explain again more simply.",
    }

    system_prompt = AGENT_PROMPTS.get(request.subjectId, AGENT_PROMPTS["biology"])
    prompt = part_prompts.get(request.part, part_prompts["concept"])

    # Try Claude API
    claude_response = None
    if ANTHROPIC_AVAILABLE and os.getenv("ANTHROPIC_API_KEY"):
        user_prompt = f"""Chapter: {request.chapterId}
Part: {request.part}

{prompt}

Previous context: {str(request.previousMessages)[:500] if request.previousMessages else "None"}"""

        claude_response = await call_claude_api(system_prompt, user_prompt, max_tokens=1500)

    # Use fallback if Claude not available
    if claude_response:
        response_text = claude_response
    else:
        response_text = generate_fallback_learn(request)

    return format_teaching_response(response_text, request.subjectId, request.part)

@app.post("/api/quiz/generate")
async def generate_quiz(request: QuizRequest):
    """Generate quiz questions"""
    questions = []
    for i in range(request.count):
        difficulty = "easy" if i < 5 else "medium" if i < 10 else "hard"
        marks = 1 if difficulty == "easy" else 2 if difficulty == "medium" else 3

        questions.append({
            "id": f"q{i+1}",
            "question": f"Sample {difficulty} question {i+1} for {request.chapterId}?",
            "questionHindi": f"{request.chapterId} ke liye {difficulty} sawal {i+1}?",
            "options": ["Option A", "Option B", "Option C", "Option D"],
            "correctAnswer": 0,
            "explanation": f"Explanation for question {i+1}. The correct answer is Option A because...",
            "explanationHindi": f"Sawal {i+1} ka spashTIkaraN. Sahi uttar vikalp A hai kyonki...",
            "difficulty": difficulty,
            "marks": marks,
        })

    return {"questions": questions}

@app.post("/api/flashcards/generate")
async def generate_flashcards(request: FlashcardRequest):
    """Generate flashcards"""
    flashcards = []
    topics = ["Definition", "Formula", "Concept", "Example", "Application"]

    for i in range(request.count):
        topic = topics[i % len(topics)]
        flashcards.append({
            "id": f"fc{i+1}",
            "front": f"{topic}: What is...? ({request.chapterId})",
            "back": f"Answer: The {topic.lower()} refers to...",
            "frontHindi": f"{topic}: ... kya hai? ({request.chapterId})",
            "backHindi": f"Uttar: {topic.lower()} ka arth hai...",
            "difficulty": "easy" if i < 7 else "medium" if i < 14 else "hard",
        })

    return {"flashcards": flashcards}

@app.post("/api/revision/generate")
async def generate_revision(request: RevisionRequest):
    """Generate revision notes"""

    content_templates = {
        "one-page": f"""# One Page Notes: {request.chapterId}

## Key Concepts
- Main concept 1
- Main concept 2
- Main concept 3

## Important Definitions
1. **Definition 1**: Meaning
2. **Definition 2**: Meaning

## Formulas
```
F = ma
E = mc²
```

## Diagrams
- Diagram 1: Description
- Diagram 2: Description

## NCERT Lines
> "Important NCERT quote"

## Memory Trick
Use: **MRS GREN** or **OIL RIG**""",

        "last-night": f"""# Last Night Revision: {request.chapterId}

## 5 Minute Quick Read

**Must Know:**
1. Point 1 (100% aayega)
2. Point 2
3. Point 3

**Formulas:**
- Formula 1
- Formula 2

**Diagrams:**
1. Diagram 1
2. Diagram 2

**Predicted Questions:**
- Long answer (5 marks)
- Short answer (3 marks)
- MCQ (1 mark)

**All the best! 🍀**""",

        "important-questions": f"""# Important Questions: {request.chapterId}

## 5 Marks (Long Answer)
1. Explain in detail with diagram
2. Describe the process

## 3 Marks (Short Answer)
3. What is...? Write importance.
4. Differentiate between...

## 2 Marks (Very Short)
5. Define...
6. Write two examples

## 1 Mark (MCQ/Fill ups)
7. ______ was discovered by...
8. The unit of ______ is...

## Answer Tips
- Use diagrams
- Write in points
- Underline key terms""",

        "formula-sheet": f"""# Formula Sheet: {request.chapterId}

## Important Formulas

### Formula 1
```
F = ma
```
**Where:** F = Force, m = mass, a = acceleration

### Formula 2
```
E = mc²
```
**Where:** E = Energy, m = mass, c = speed of light

## Units
| Quantity | Unit | Symbol |
|----------|------|--------|
| Force | Newton | N |
| Energy | Joule | J |

## Constants
- g = 9.8 m/s²
- c = 3 × 10⁸ m/s

## Memory Trick
**F = ma** → "Force = Maa ka Aashirwad"""",
    }

    content = content_templates.get(request.type, content_templates["one-page"])

    return {
        "content": content,
        "contentHindi": f"""# Hindi Notes: {request.chapterId}

## Mukhya AvdharaNaeN
- Mukhya avdharaNa 1
- Mukhya avdharaNa 2

## Mahatvapoorn ParibhaashaeN
1. **Paribhaasha 1**: Arth
2. **Paribhaasha 2**: Arth

## Sootra
```
F = ma
```

## Smriti Tarkeeb
**F = ma** → "Force = Maa ka Aashirwad"""",
    }

@app.post("/api/upload/pdf")
async def upload_pdf(background_tasks: BackgroundTasks, file: UploadFile = File(...), subjectId: str = Form(...)):
    """Upload and process PDF - extract text, chunk, embed, store"""
    try:
        contents = await file.read()

        # Extract text
        text = extract_text_from_pdf(contents)
        if not text or len(text.strip()) < 100:
            raise HTTPException(status_code=400, detail="PDF text extraction failed or text too short")

        # Detect chapters
        chapters = detect_chapters(text)

        # Chunk text
        chunks = chunk_text(text)

        # Store in vector DB (async in background)
        collection = subject_collections.get(subjectId, subject_collections["biology"])

        chunk_ids = []
        embeddings = []
        documents = []
        metadatas = []

        for i, chunk in enumerate(chunks):
            chunk_id = f"{file.filename}_chunk_{i}"
            embedding = get_embedding(chunk)

            if embedding:
                chunk_ids.append(chunk_id)
                embeddings.append(embedding)
                documents.append(chunk)
                metadatas.append({
                    "source": file.filename,
                    "chunk_index": i,
                    "subject": subjectId,
                    "detected_chapters": json.dumps(chapters[:5])
                })

        # Batch add to ChromaDB
        if chunk_ids:
            collection.add(
                ids=chunk_ids,
                embeddings=embeddings,
                documents=documents,
                metadatas=metadatas
            )

        return {
            "uploadId": hashlib.md5(file.filename.encode()).hexdigest(),
            "status": "completed",
            "chaptersDetected": chapters[:10],
            "totalChunks": len(chunks),
            "textLength": len(text),
            "subject": subjectId,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/rag/retrieve")
async def retrieve_chunks(request: RAGRequest):
    """Retrieve relevant chunks from vector DB using local embeddings (FREE)"""
    collection = subject_collections.get(request.subjectId, subject_collections["biology"])

    try:
        embedding = get_embedding(request.query)
        if embedding:
            results = collection.query(
                query_embeddings=[embedding],
                n_results=request.topK
            )
            chunks = []
            if results and results["documents"] and len(results["documents"]) > 0:
                for i, doc in enumerate(results["documents"][0]):
                    chunk_data = {
                        "text": doc,
                        "score": 0.9 - (i * 0.1),  # Approximate score
                        "metadata": results["metadatas"][0][i] if results.get("metadatas") else {}
                    }
                    chunks.append(chunk_data)
            return {"chunks": chunks}
        else:
            return {"chunks": [{"text": "No local embeddings available. Install sentence-transformers for RAG.", "score": 0.5, "metadata": {}}]}
    except Exception as e:
        return {"chunks": [{"text": f"RAG retrieval note: {str(e)}", "score": 0, "metadata": {}}]}

@app.get("/api/upload/status/{upload_id}")
async def upload_status(upload_id: str):
    """Check upload status"""
    return {
        "status": "completed",
        "progress": 100,
        "chapters": ["Chapter 1", "Chapter 2", "Chapter 3"],
    }

@app.get("/api/stats")
async def get_stats():
    """Get API usage stats for monitoring"""
    return {
        "cache_size": len(response_cache),
        "cache_hits": sum(1 for v in response_cache.values() if (datetime.now() - v["timestamp"]).seconds < CACHE_TTL),
        "local_embeddings": LOCAL_EMBEDDINGS,
        "claude_available": ANTHROPIC_AVAILABLE and bool(os.getenv("ANTHROPIC_API_KEY")),
        "subjects_indexed": {s: subject_collections[s].count() for s in subject_collections},
    }

if __name__ == "__main__":
    import uvicorn
    print("🚀 Starting RBSE Study Tutor API...")
    print(f"   Local Embeddings: {'✅ FREE' if LOCAL_EMBEDDINGS else '❌ Not available'}")
    print(f"   Claude API: {'✅ Available' if ANTHROPIC_AVAILABLE and os.getenv('ANTHROPIC_API_KEY') else '⚠️  Fallback mode (FREE)'}")
    print(f"   Cache: ✅ Enabled (saves API costs)")
    print(f"   RAG: ✅ Enabled with ChromaDB")
    uvicorn.run(app, host="0.0.0.0", port=8000)
