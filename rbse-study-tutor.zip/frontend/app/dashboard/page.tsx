"use client"

import { useState } from "react"
import { useUser } from "@clerk/nextjs"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { 
  BookOpen, 
  Brain, 
  Upload, 
  MessageCircle, 
  Trophy,
  Flame,
  Clock,
  TrendingUp,
  ChevronRight,
  GraduationCap
} from "lucide-react"
import { SUBJECTS, getChaptersBySubject } from "@/lib/subjects"
import { useAppStore } from "@/hooks/useStore"
import { cn, getSubjectGradient, getSubjectIcon } from "@/lib/utils"
import { Subject } from "@/types"

export default function DashboardPage() {
  const { user } = useUser()
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null)
  const { progress } = useAppStore()

  const stats = [
    { icon: Flame, label: "Study Streak", value: "5 days", color: "text-orange-500" },
    { icon: Clock, label: "Total Time", value: "12h 30m", color: "text-blue-500" },
    { icon: Brain, label: "Flashcards", value: "48 mastered", color: "text-purple-500" },
    { icon: Trophy, label: "Avg Score", value: "78%", color: "text-amber-500" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <GraduationCap className="w-8 h-8 text-emerald-600" />
            <div>
              <h1 className="text-xl font-bold text-slate-900">RBSE Tutor</h1>
              <p className="text-xs text-slate-500">Your AI Bhaiya</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-slate-900">{user?.firstName || "Student"}</p>
              <p className="text-xs text-slate-500">Class 12 RBSE</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
              <span className="text-emerald-700 font-bold">{(user?.firstName?.[0] || "S").toUpperCase()}</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Welcome Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-6 mb-8 text-white shadow-lg"
        >
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-1">Namaste, {user?.firstName || "Bhai"}! 🙏</h2>
              <p className="text-emerald-100">Aaj kya padhna hai? Choose a subject below!</p>
              <p className="text-emerald-200 text-sm mt-1 hindi-text">आज क्या पढ़ना है?</p>
            </div>
            <div className="hidden md:block">
              <div className="text-4xl">📚</div>
            </div>
          </div>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm"
            >
              <div className="flex items-center gap-2 mb-2">
                <stat.icon className={`w-5 h-5 ${stat.color}`} />
                <span className="text-sm text-slate-500">{stat.label}</span>
              </div>
              <p className="text-xl font-bold text-slate-900">{stat.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Subject Selection */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Choose Your Subject
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {SUBJECTS.map((subject, i) => (
              <motion.button
                key={subject.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedSubject(selectedSubject === subject.id ? null : subject.id)}
                className={cn(
                  "p-4 rounded-xl border-2 text-left transition-all",
                  selectedSubject === subject.id
                    ? `border-${subject.color}-500 bg-${subject.color}-50 shadow-md`
                    : "border-slate-200 bg-white hover:border-slate-300"
                )}
              >
                <div className="text-3xl mb-2">{subject.icon}</div>
                <h4 className="font-semibold text-slate-900">{subject.name}</h4>
                <p className="text-xs text-slate-500 hindi-text">{subject.nameHindi}</p>
                <p className="text-xs text-slate-400 mt-1">{subject.totalChapters} chapters</p>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Chapter Selection */}
        <AnimatePresence>
          {selectedSubject && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-8"
            >
              <h3 className="text-lg font-semibold text-slate-900 mb-4 flex items-center gap-2">
                <Brain className="w-5 h-5" />
                Select Chapter
              </h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {getChaptersBySubject(selectedSubject).map((chapter, i) => (
                  <motion.div
                    key={chapter.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className={cn(
                      "p-4 rounded-xl border-2 bg-white transition-all hover:shadow-md",
                      getSubjectGradient(selectedSubject)
                    )}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <span className="text-xs font-medium px-2 py-1 rounded-full bg-white/80">
                          Ch. {chapter.number}
                        </span>
                        <span className={cn(
                          "text-xs ml-2 px-2 py-1 rounded-full",
                          chapter.difficulty === "easy" && "bg-green-100 text-green-700",
                          chapter.difficulty === "medium" && "bg-yellow-100 text-yellow-700",
                          chapter.difficulty === "hard" && "bg-red-100 text-red-700",
                        )}>
                          {chapter.difficulty}
                        </span>
                      </div>
                      <span className="text-xs text-slate-400">{chapter.estimatedTime} min</span>
                    </div>
                    <h4 className="font-semibold text-slate-900 mb-1">{chapter.name}</h4>
                    <p className="text-sm text-slate-600 hindi-text mb-3">{chapter.nameHindi}</p>
                    <p className="text-xs text-slate-500 mb-4">{chapter.description}</p>

                    <div className="flex gap-2">
                      <Link href={`/learn?subject=${selectedSubject}&chapter=${chapter.id}`} className="flex-1">
                        <button className="w-full px-3 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium flex items-center justify-center gap-1">
                          Learn
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </Link>
                      <Link href={`/quiz?subject=${selectedSubject}&chapter=${chapter.id}`} className="flex-1">
                        <button className="w-full px-3 py-2 rounded-lg bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium">
                          Quiz
                        </button>
                      </Link>
                      <Link href={`/flashcards?subject=${selectedSubject}&chapter=${chapter.id}`} className="flex-1">
                        <button className="w-full px-3 py-2 rounded-lg bg-purple-500 hover:bg-purple-600 text-white text-sm font-medium">
                          Cards
                        </button>
                      </Link>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Quick Actions */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <Link href="/doubt">
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="p-6 rounded-xl bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200 cursor-pointer"
            >
              <MessageCircle className="w-8 h-8 text-amber-600 mb-3" />
              <h4 className="font-semibold text-slate-900">Doubt Solver</h4>
              <p className="text-sm text-slate-600 mt-1">"Samajh nahi aaya?" Ask anything!</p>
              <p className="text-xs text-slate-500 hindi-text mt-1">कोई भी सवाल पूछो</p>
            </motion.div>
          </Link>

          <Link href="/revision">
            <motion.div
              whileHover={{ scale: 1.02 }}
              className="p-6 rounded-xl bg-gradient-to-br from-rose-50 to-pink-50 border border-rose-200 cursor-pointer"
            >
              <TrendingUp className="w-8 h-8 text-rose-600 mb-3" />
              <h4 className="font-semibold text-slate-900">Revision Notes</h4>
              <p className="text-sm text-slate-600 mt-1">One-page notes, last night prep</p>
              <p className="text-xs text-slate-500 hindi-text mt-1">रिवीजन नोट्स</p>
            </motion.div>
          </Link>

          <motion.div
            whileHover={{ scale: 1.02 }}
            className="p-6 rounded-xl bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 cursor-pointer"
          >
            <Upload className="w-8 h-8 text-blue-600 mb-3" />
            <h4 className="font-semibold text-slate-900">Upload PDF</h4>
            <p className="text-sm text-slate-600 mt-1">Add your textbooks for AI teaching</p>
            <p className="text-xs text-slate-500 hindi-text mt-1">पुस्तकें अपलोड करो</p>
          </motion.div>
        </div>
      </main>
    </div>
  )
}
