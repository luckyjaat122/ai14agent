"use client"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { 
  Send, 
  Bot, 
  User, 
  HelpCircle,
  Sparkles,
  Volume2,
  BookOpen
} from "lucide-react"
import { useAppStore } from "@/hooks/useStore"
import { sendChatMessage } from "@/lib/api"
import { cn } from "@/lib/utils"
import ReactMarkdown from "react-markdown"
import remarkGfm from "remark-gfm"
import { SUBJECTS } from "@/lib/subjects"

export default function DoubtPage() {
  const [selectedSubject, setSelectedSubject] = useState("biology")
  const [messages, setMessages] = useState<{role: string; content: string; id: string; isSimplified?: boolean}[]>([
    {
      id: "welcome",
      role: "tutor",
      content: `**Namaste Bhai!** 🙏\n\nMain tumhara AI Bhaiya hoon. Kuch bhi pucho - "Samajh nahi aaya" bhi chalega!\n\n**Kya puch sakte ho:**\n- Kisi bhi subject ka doubt\n- "Ye formula kahan se aaya?"\n- "Diagram samjhao"\n- "Aur simple batao"\n\nBas neeche type karo! 👇`,
    }
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const handleSend = async () => {
    if (!input.trim() || isLoading) return

    const userMsg = input.trim()
    setInput("")
    const userMessage = { id: Date.now().toString(), role: "student", content: userMsg }
    setMessages(prev => [...prev, userMessage])

    setIsLoading(true)
    try {
      const isDoubt = userMsg.toLowerCase().includes("samajh") || 
                      userMsg.toLowerCase().includes("nahi") ||
                      userMsg.toLowerCase().includes("doubt")

      const response = await sendChatMessage({
        message: userMsg,
        subjectId: selectedSubject,
        isDoubt,
      })

      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: "tutor",
        content: response.message,
        isSimplified: isDoubt,
      }])
    } catch (error) {
      const isDoubt = userMsg.toLowerCase().includes("samajh") || userMsg.toLowerCase().includes("nahi")

      if (isDoubt) {
        setMessages(prev => [...prev, {
          id: (Date.now() + 1).toString(),
          role: "tutor",
          content: `Arre koi baat nahi! 😊\n\nMain **aur bhi simple** samjhata hoon...\n\n**Step 1:** Socho jaise tumhare ghar me...\n**Step 2:** Ye concept waise hi kaam karta hai\n**Step 3:** Bas! Itna hi tha!\n\nAb samajh aaya? Nahi aaya toh aur simple bataunga! 👍\n\n*Pro tip: Diagram banao dimaag me - yaad zyada der tak rahega!*`,
          isSimplified: true,
        }])
      } else {
        setMessages(prev => [...prev, {
          id: (Date.now() + 1).toString(),
          role: "tutor",
          content: `Badiya sawal! 🤔\n\n**${userMsg} ka jawab:**\n\nSimple words me - ye concept aise samjho...\n\n**Example:**\nSocho jaise daily life me...\n\n**Key Point:**\n- Important point 1\n- Important point 2\n\nAur detail chahiye toh pucho! "Samajh nahi aaya" bhi likh sakte ho!`,
        }])
      }
    }
    setIsLoading(false)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const speakText = (text: string) => {
    const cleanText = text.replace(/[#*_`]/g, "")
    const utterance = new SpeechSynthesisUtterance(cleanText)
    utterance.lang = "hi-IN"
    utterance.rate = 0.9
    speechSynthesis.speak(utterance)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <HelpCircle className="w-8 h-8 text-amber-500" />
            <div>
              <h1 className="font-semibold text-slate-900">Doubt Solver</h1>
              <p className="text-xs text-slate-500 hindi-text">कोई भी सवाल पूछो - कोई शर्म नहीं!</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 mr-2">Subject:</span>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="px-3 py-1.5 rounded-lg bg-slate-100 text-sm font-medium text-slate-700 border-none outline-none"
            >
              {SUBJECTS.map(s => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex gap-3",
                message.role === "student" ? "flex-row-reverse" : "flex-row"
              )}
            >
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
                message.role === "tutor" ? "bg-amber-100 text-amber-700" : "bg-blue-100 text-blue-700"
              )}>
                {message.role === "tutor" ? <Bot className="w-5 h-5" /> : <User className="w-5 h-5" />}
              </div>
              <div className={cn(
                "max-w-[80%] rounded-2xl px-4 py-3",
                message.role === "tutor" 
                  ? "bg-white border border-slate-200 shadow-sm" 
                  : "bg-emerald-500 text-white"
              )}>
                {message.role === "tutor" && (
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-medium text-amber-600">Bhaiya</span>
                    {message.isSimplified && (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">
                        Simplified
                      </span>
                    )}
                  </div>
                )}
                <div className={cn(
                  "prose prose-sm max-w-none",
                  message.role === "student" && "prose-invert"
                )}>
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {message.content}
                  </ReactMarkdown>
                </div>
                {message.role === "tutor" && (
                  <div className="flex items-center gap-2 mt-3 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => speakText(message.content)}
                      className="text-xs text-slate-400 hover:text-amber-600 flex items-center gap-1"
                    >
                      <Volume2 className="w-3 h-3" />
                      Listen
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          ))}

          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-3"
            >
              <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center">
                <Bot className="w-5 h-5 text-amber-700" />
              </div>
              <div className="bg-white border border-slate-200 rounded-2xl px-4 py-3 shadow-sm">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-amber-500 rounded-full typing-dot" />
                  <div className="w-2 h-2 bg-amber-500 rounded-full typing-dot" />
                  <div className="w-2 h-2 bg-amber-500 rounded-full typing-dot" />
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Quick Suggestions */}
      <div className="bg-white border-t border-slate-200 px-4 py-2">
        <div className="max-w-4xl mx-auto flex gap-2 overflow-x-auto pb-2">
          {["Samajh nahi aaya", "Aur simple batao", "Diagram samjhao", "Example do", "Formula kahan se aaya?"].map((suggestion) => (
            <button
              key={suggestion}
              onClick={() => setInput(suggestion)}
              className="px-3 py-1.5 rounded-full bg-slate-100 hover:bg-amber-100 text-xs text-slate-600 hover:text-amber-700 whitespace-nowrap transition-colors"
            >
              {suggestion}
            </button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className="bg-white border-t border-slate-200 px-4 py-4">
        <div className="max-w-4xl mx-auto flex items-end gap-2">
          <div className="flex-1">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Kuch bhi pucho... 'Samajh nahi aaya' bhi chalega!"
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 resize-none text-sm"
              rows={2}
            />
          </div>
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 disabled:bg-slate-300 text-white font-medium flex items-center gap-1"
          >
            <Send className="w-4 h-4" />
            Send
          </button>
        </div>
      </div>
    </div>
  )
}
