"use client"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { 
  RotateCw, 
  ChevronLeft, 
  ChevronRight,
  Check,
  X,
  Brain,
  Sparkles
} from "lucide-react"
import { getSubjectById, getChapterById } from "@/lib/subjects"
import { useAppStore } from "@/hooks/useStore"
import { generateFlashcards } from "@/lib/api"
import { cn } from "@/lib/utils"

function FlashcardsContent() {
  const searchParams = useSearchParams()
  const subjectId = searchParams.get("subject") || "biology"
  const chapterId = searchParams.get("chapter") || "bio-1"

  const [flashcards, setFlashcards] = useState<any[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isFlipped, setIsFlipped] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [mastered, setMastered] = useState<Set<string>>(new Set())

  const subject = getSubjectById(subjectId)
  const chapter = getChapterById(chapterId)

  useEffect(() => {
    loadFlashcards()
  }, [])

  const loadFlashcards = async () => {
    setIsLoading(true)
    try {
      const response = await generateFlashcards({
        subjectId,
        chapterId,
        count: 20,
      })
      setFlashcards(response.flashcards)
    } catch (error) {
      setFlashcards([
        { id: "1", front: `What is ${chapter?.topics[0]}?`, back: "The main concept of this chapter", frontHindi: `${chapter?.topics[0]} kya hai?`, backHindi: "Is chapter ka mukhya concept" },
        { id: "2", front: "Key definition", back: "Important definition from NCERT", frontHindi: "Mukhya paribhasha", backHindi: "NCERT se mahatvapoorn paribhasha" },
        { id: "3", front: "Formula", back: "Key formula to remember", frontHindi: "Sutra", backHindi: "Yaad rakhne wala mukhya sutra" },
      ])
    }
    setIsLoading(false)
  }

  const handleFlip = () => setIsFlipped(!isFlipped)

  const handleNext = () => {
    setIsFlipped(false)
    setCurrentIndex((prev) => (prev + 1) % flashcards.length)
  }

  const handlePrevious = () => {
    setIsFlipped(false)
    setCurrentIndex((prev) => (prev - 1 + flashcards.length) % flashcards.length)
  }

  const handleMastered = () => {
    const newMastered = new Set(mastered)
    newMastered.add(flashcards[currentIndex].id)
    setMastered(newMastered)
    handleNext()
  }

  const handleNeedPractice = () => {
    handleNext()
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-slate-600">Creating flashcards...</p>
          <p className="text-sm text-slate-400 hindi-text">फ्लैशकार्ड बन रहे हैं</p>
        </div>
      </div>
    )
  }

  const currentCard = flashcards[currentIndex]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <span className="text-4xl mb-2 block">{subject?.icon}</span>
          <h1 className="text-2xl font-bold text-slate-900">Flashcards</h1>
          <p className="text-slate-600">{chapter?.name}</p>
          <p className="text-sm text-slate-500 hindi-text">{chapter?.nameHindi}</p>
          <div className="flex items-center justify-center gap-4 mt-4 text-sm text-slate-500">
            <span>Card {currentIndex + 1} of {flashcards.length}</span>
            <span className="text-emerald-600 font-medium">{mastered.size} mastered</span>
          </div>
        </div>

        {/* Progress */}
        <div className="h-2 bg-slate-200 rounded-full mb-8 overflow-hidden">
          <motion.div
            className="h-full bg-purple-500 rounded-full"
            animate={{ width: `${((currentIndex + 1) / flashcards.length) * 100}%` }}
          />
        </div>

        {/* Flashcard */}
        <div className="perspective-1000 mb-8">
          <motion.div
            onClick={handleFlip}
            className={cn(
              "relative w-full h-80 cursor-pointer",
              "transition-transform duration-500 transform-style-3d"
            )}
            animate={{ rotateY: isFlipped ? 180 : 0 }}
            transition={{ duration: 0.6 }}
            style={{ transformStyle: "preserve-3d" }}
          >
            {/* Front */}
            <div
              className="absolute inset-0 backface-hidden rounded-2xl bg-white shadow-xl border-2 border-purple-200 p-8 flex flex-col items-center justify-center text-center"
              style={{ backfaceVisibility: "hidden" }}
            >
              <Brain className="w-10 h-10 text-purple-400 mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">{currentCard?.front}</h3>
              {currentCard?.frontHindi && (
                <p className="text-lg text-slate-600 hindi-text">{currentCard.frontHindi}</p>
              )}
              <p className="text-xs text-slate-400 mt-6">Click to flip</p>
            </div>

            {/* Back */}
            <div
              className="absolute inset-0 backface-hidden rounded-2xl bg-gradient-to-br from-purple-50 to-indigo-50 shadow-xl border-2 border-purple-300 p-8 flex flex-col items-center justify-center text-center"
              style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}
            >
              <Sparkles className="w-10 h-10 text-purple-500 mb-4" />
              <h3 className="text-xl font-semibold text-slate-900 mb-2">{currentCard?.back}</h3>
              {currentCard?.backHindi && (
                <p className="text-lg text-slate-700 hindi-text">{currentCard.backHindi}</p>
              )}
            </div>
          </motion.div>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-4 mb-6">
          <button
            onClick={handlePrevious}
            className="p-3 rounded-full bg-white shadow-md hover:shadow-lg text-slate-600 hover:text-purple-600"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={handleFlip}
            className="px-6 py-3 rounded-xl bg-purple-500 hover:bg-purple-600 text-white font-medium flex items-center gap-2"
          >
            <RotateCw className="w-4 h-4" />
            Flip Card
          </button>

          <button
            onClick={handleNext}
            className="p-3 rounded-full bg-white shadow-md hover:shadow-lg text-slate-600 hover:text-purple-600"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>

        {/* Mastery buttons */}
        <AnimatePresence>
          {isFlipped && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3 justify-center"
            >
              <button
                onClick={handleNeedPractice}
                className="px-6 py-3 rounded-xl bg-red-100 hover:bg-red-200 text-red-700 font-medium flex items-center gap-2"
              >
                <X className="w-4 h-4" />
                Need Practice
              </button>
              <button
                onClick={handleMastered}
                className="px-6 py-3 rounded-xl bg-emerald-100 hover:bg-emerald-200 text-emerald-700 font-medium flex items-center gap-2"
              >
                <Check className="w-4 h-4" />
                Mastered!
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

export default function FlashcardsPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full" />
      </div>
    }>
      <FlashcardsContent />
    </Suspense>
  )
}
