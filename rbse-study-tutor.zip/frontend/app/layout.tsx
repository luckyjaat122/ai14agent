import type { Metadata } from "next"
import { Inter, Noto_Sans_Devanagari } from "next/font/google"
import { ClerkProvider } from "@clerk/nextjs"
import { Toaster } from "react-hot-toast"
import "./globals.css"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const notoSansDevanagari = Noto_Sans_Devanagari({
  subsets: ["devanagari"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-hindi",
})

export const metadata: Metadata = {
  title: "RBSE Study Tutor - AI Personal Tutor for Class 12",
  description: "Your AI elder brother who teaches RBSE Class 12 Science, Hindi & English like a personal tutor. Simple, fun, and effective learning.",
  keywords: ["RBSE", "Class 12", "Science", "AI Tutor", "Biology", "Physics", "Chemistry", "Hindi", "English"],
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <ClerkProvider>
      <html lang="en" className={`${inter.variable} ${notoSansDevanagari.variable}`}>
        <body className="font-sans antialiased min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
          <Toaster
            position="top-center"
            toastOptions={{
              duration: 4000,
              style: {
                background: "#1e293b",
                color: "#fff",
                borderRadius: "12px",
                padding: "12px 20px",
              },
            }}
          />
          {children}
        </body>
      </html>
    </ClerkProvider>
  )
}
