"use client"

import { useState, useEffect, useRef, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { 
  Send, 
  Bot, 
  User, 
  Play,
  Clock,
  ChevronRight,
  Volume2,
  HelpCircle,
  Sparkles,
  Target,
  Zap,
  BookOpen,
  Brain
} from "lucide-react"
import { useAppStore } from "@/hooks/useStore"
import { getSubjectById, getChapterById, getAgentConfig } from "@/lib/subjects"
import { sendChatMessage, startLearning } from "@/lib/api"
import { cn } from "@/lib/utils"
import ReactMarkdown from "react-markdown"
import remarkGfm from "remark-gfm"

function LearnContent() {
  const searchParams = useSearchParams()
  const subjectId = searchParams.get("subject") || "biology"
  const chapterId = searchParams.get("chapter") || "bio-1"

  const { activeSession, startSession, addMessage } = useAppStore()
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [currentPart, setCurrentPart] = useState(0)
  const [showPartMenu, setShowPartMenu] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [hasStarted, setHasStarted] = useState(false)

  const subject = getSubjectById(subjectId)
  const chapter = getChapterById(chapterId)
  const agent = getAgentConfig(subjectId)

  const parts = [
    { id: "introduction", name: "Introduction", hindi: "परिचय", icon: BookOpen, time: "5 min", color: "bg-blue-500" },
    { id: "concept", name: "Concepts", hindi: "अवधारणाएँ", icon: Brain, time: "15 min", color: "bg-emerald-500" },
    { id: "memory", name: "Memory", hindi: "याद करना", icon: Sparkles, time: "5 min", color: "bg-amber-500" },
    { id: "revision", name: "Revision", hindi: "रिवीजन", icon: Target, time: "3 min", color: "bg-rose-500" },
    { id: "testing", name: "Test", hindi: "टेस्ट", icon: Zap, time: "2 min", color: "bg-purple-500" },
  ]

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [activeSession?.messages])

  const handleStartSession = async () => {
    if (hasStarted) return
    setHasStarted(true)
    startSession(chapterId, subjectId)

    setIsLoading(true)
    try {
      const response = await startLearning({
        subjectId,
        chapterId,
        part: "introduction",
      })
      addMessage({
        role: "tutor",
        content: response.message,
        contentHindi: response.messageHindi,
        type: "introduction",
      })
      setCurrentPart(0)
    } catch (error) {
      addMessage({
        role: "tutor",
        content: `Namaste bhai! Main ${agent.name} hoon. Aaj hum **${chapter?.name}** padhenge. Chalo shuru karte hain! 🎯\n\n**Ye chapter kya hai?**\n${chapter?.description}\n\n**Kyun padhna hai?**\nYe chapter board exam me 8-10 marks ka aata hai. Aur real life me bhi kaam aata hai - ${chapter?.topics?.[0] || "daily life"} se related.\n\n**Real life me kaise kaam aata hai?**\nJaante ho, jo bhi tum roz dekhte ho - ${chapter?.topics?.slice(0, 2).join(", ") || "nature"} - sab is chapter me hai!\n\nTaiyaar ho? "Concepts" pe click karo! 🚀`,
        type: "introduction",
      })
    }
    setIsLoading(false)
  }

  const handlePartChange = async (partIndex: number) => {
    if (partIndex === currentPart) return
    setCurrentPart(partIndex)
    setIsLoading(true)

    const part = parts[partIndex].id as any
    try {
      const response = await startLearning({
        subjectId,
        chapterId,
        part,
        previousMessages: activeSession?.messages.map(m => ({
          role: m.role,
          content: m.content,
        })),
      })
      addMessage({
        role: "tutor",
        content: response.message,
        contentHindi: response.messageHindi,
        type: part,
      })
    } catch (error) {
      const fallbackMessages: Record<string, string> = {
        concept: `## 🧠 Concept Teaching\n\nChalo ab asli concept samajhte hain!\n\n**${chapter?.topics?.[0] || "Main Topic"}**\n\nSimple words me - ${chapter?.description}\n\n*Example:* Socho jaise... (real life example)\n\n**Important NCERT Line:**\n"Ye chapter ka sabse important sentence hai - isko yaad rakhna"\n\nSamajh aaya? Nahi aaya toh neeche "Samajh nahi aaya" likh do! 👇`,
        memory: `## ✨ Memory Mode\n\nAb isko yaad kaise rakhen?\n\n**Mnemonic:**\n"Kuch funny yaad karo - jaise..."\n\n**Trick:**\n- Pehla letter yaad karo\n- Rhyme banao\n- Picture banao dimaag me\n\n**Cheat Code:**\nExam me ye formula yaad rakhna - bas yehi aata hai!\n\nAb test ke liye taiyaar? 🎯`,
        revision: `## 📝 Quick Revision\n\n**Key Points (2 minute me):**\n\n1. ${chapter?.topics?.[0] || "Point 1"}\n2. ${chapter?.topics?.[1] || "Point 2"}\n3. ${chapter?.topics?.[2] || "Point 3"}\n\n**Important Definitions:**\n- Definition 1\n- Definition 2\n\n**Formula Sheet:**\n\n\`\`\`\nFormula 1 = ...\nFormula 2 = ...\n\`\`\`\n\n**Most Important for Board:**\n- Question type 1\n- Question type 2\n\nAb TEST! ⚡`,
        testing: `## ⚡ Test Yourself\n\n**5 Easy Questions:**\n\n1. ${chapter?.topics?.[0] || "Topic"} kya hai?\n2. Basic definition batao\n\n**5 Medium Questions:**\n\n3. Explain with example\n4. Compare karo\n\n**5 Board Level:**\n\n5. Long answer type\n\nAnswer do neeche! Main check karunga! ✅`,
      }
      addMessage({
        role: "tutor",
        content: fallbackMessages[part] || "Chalo aage badhte hain!",
        type: part,
      })
    }
    setIsLoading(false)
    setShowPartMenu(false)
  }

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return

    const userMessage = input.trim()
    setInput("")
    addMessage({
      role: "student",
      content: userMessage,
      type: "general",
    })

    setIsLoading(true)
    try {
      const isDoubt = userMessage.toLowerCase().includes("samajh") || 
                      userMessage.toLowerCase().includes("nahi") ||
                      userMessage.toLowerCase().includes("doubt")

      const response = await sendChatMessage({
        message: userMessage,
        subjectId,
        chapterId,
        sessionId: activeSession?.id,
        isDoubt,
        context: activeSession?.messages.slice(-5).map(m => `${m.role}: ${m.content}`).join("\n"),
      })

      addMessage({
        role: "tutor",
        content: response.message,
        contentHindi: response.messageHindi,
        type: isDoubt ? "doubt" : "general",
        isSimplified: isDoubt,
      })
    } catch (error) {
      const isDoubt = userMessage.toLowerCase().includes("samajh") || 
                      userMessage.toLowerCase().includes("nahi")

      if (isDoubt) {
        addMessage({
          role: "tutor",
          content: `Arre koi baat nahi bhai! 😊\n\nMain aur simple samjhata hoon.\n\n**Aur Simple Version:**\n\nSocho jaise... (even simpler analogy)\n\n**Step-by-step:**\n1. Pehle ye karo\n2. Phir ye\n3. Bas ho gaya!\n\nAb samajh aaya? Nahi aaya toh aur simple bataunga! 👍`,
          type: "doubt",
          isSimplified: true,
        })
      } else {
        addMessage({
          role: "tutor",
          content: `Badiya sawal! 🤔\n\n${userMessage} ka jawab:\n\n**Simple me:**\nYe concept aise samjho...\n\n**Example:**\nDaily life se...\n\nAur kuch puchna hai toh pucho! "Samajh nahi aaya" bhi likh sakte ho!`,
          type: "general",
        })
      }
    }
    setIsLoading(false)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const speakText = (text: string) => {
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = "hi-IN"
    utterance.rate = 0.9
    speechSynthesis.speak(utterance)
  }

  if (!hasStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-md"
        >
          <div className="text-6xl mb-4">{subject?.icon}</div>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">{chapter?.name}</h1>
          <p className="text-lg text-slate-600 hindi-text mb-2">{chapter?.nameHindi}</p>
          <p className="text-sm text-slate-500 mb-6">{chapter?.description}</p>

          <div className="bg-white rounded-xl p-4 border border-slate-200 mb-6 text-left">
            <h3 className="font-semibold text-sm text-slate-900 mb-2">Topics covered:</h3>
            <ul className="space-y-1">
              {chapter?.topics.map((topic, i) => (
                <li key={i} className="text-sm text-slate-600 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  {topic}
                </li>
              ))}
            </ul>
          </div>

          <div className="flex items-center justify-center gap-2 text-sm text-slate-500 mb-6">
            <Clock className="w-4 h-4" />
            <span>~30 minutes session</span>
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleStartSession}
            className="px-8 py-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-lg shadow-lg shadow-emerald-500/25 flex items-center gap-2 mx-auto"
          >
            <Play className="w-5 h-5" />
            Start Learning Session
          </motion.button>

          <p className="text-xs text-slate-400 mt-4 hindi-text">
            {agent.personality}
          </p>
        </motion.div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100 flex flex-col">
      <header className="bg-white border-b border-slate-200 px-4 py-3">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{subject?.icon}</span>
            <div>
              <h1 className="font-semibold text-slate-900 text-sm">{chapter?.name}</h1>
              <p className="text-xs text-slate-500 hindi-text">{chapter?.nameHindi}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowPartMenu(!showPartMenu)}
              className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-sm font-medium text-slate-700 flex items-center gap-1"
            >
              {parts[currentPart].name}
              <ChevronRight className={`w-4 h-4 transition-transform ${showPartMenu ? "rotate-90" : ""}`} />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {showPartMenu && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white border-b border-slate-200 overflow-hidden"
          >
            <div className="max-w-4xl mx-auto px-4 py-3 flex gap-2 overflow-x-auto">
              {parts.map((part, i) => (
                <button
                  key={part.id}
                  onClick={() => handlePartChange(i)}
                  className={cn(
                    "flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all",
                    i === currentPart
                      ? `${part.color} text-white`
                      : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                  )}
                >
                  <part.icon className="w-4 h-4" />
                  <span>{part.name}</span>
                  <span className="text-xs opacity-70">({part.time})</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="bg-white px-4 py-2 border-b border-slate-100">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Session Progress</span>
            <span className="ml-auto">{Math.round(((currentPart + 1) / parts.length) * 100)}%</span>
          </div>
          <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
            <motion.div
              className={cn("h-full rounded-full", parts[currentPart].color)}
              initial={{ width: 0 }}
              animate={{ width: `${((currentPart + 1) / parts.length) * 100}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-6">
        <div className="max-w-4xl mx-auto space-y-4">
          {activeSession?.messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className={cn(
                "flex gap-3",
                message.role === "student" ? "flex-row-reverse" : "flex-row"
              )}
            >
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center shrink-0",
                message.role === "tutor" ? "bg-emerald-100 text-emerald-700" : "bg-blue-100 text-blue-700"
              )}>
                {message.role === "tutor" ? <Bot className="w-5 h-5" /> : <User className="w-5 h-5" />}
              </div>
              <div className={cn(
                "max-w-[80%] rounded-2xl px-4 py-3",
                message.role === "tutor" 
                  ? "bg-white border border-slate-200 shadow-sm tutor-bubble" 
                  : "bg-emerald-500 text-white"
              )}>
                {message.role === "tutor" && (
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-medium text-emerald-600">{agent.name}</span>
                    {message.isSimplified && (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">
                        Simplified
                      </span>
                    )}
                  </div>
                )}
                <div className={cn(
                  "prose prose-sm max-w-none",
                  message.role === "student" && "prose-invert"
                )}>
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                    {message.content}
                  </ReactMarkdown>
                </div>
                {message.contentHindi && message.role === "tutor" && (
                  <div className="mt-3 pt-3 border-t border-slate-100">
                    <p className="text-sm text-slate-600 hindi-text">{message.contentHindi}</p>
                  </div>
                )}
                {message.role === "tutor" && (
                  <div className="flex items-center gap-2 mt-3 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => speakText(message.contentHindi || message.content)}
                      className="text-xs text-slate-400 hover:text-emerald-600 flex items-center gap-1"
                    >
                      <Volume2 className="w-3 h-3" />
                      Listen
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          ))}

          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-3"
            >
              <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center">
                <Bot className="w-5 h-5 text-emerald-700" />
              </div>
              <div className="bg-white border border-slate-200 rounded-2xl px-4 py-3 shadow-sm">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full typing-dot" />
                  <div className="w-2 h-2 bg-emerald-500 rounded-full typing-dot" />
                  <div className="w-2 h-2 bg-emerald-500 rounded-full typing-dot" />
                </div>
              </div>
            </motion.div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="bg-white border-t border-slate-200 px-4 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-end gap-2">
            <div className="flex-1 relative">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message... (or 'Samajh nahi aaya')"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 resize-none text-sm"
                rows={2}
              />
            </div>
            <div className="flex flex-col gap-2">
              <button
                onClick={() => setInput("Samajh nahi aaya")}
                className="px-3 py-1.5 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-700 text-xs font-medium flex items-center gap-1"
              >
                <HelpCircle className="w-3 h-3" />
                Did not get it
              </button>
              <button
                onClick={handleSendMessage}
                disabled={isLoading || !input.trim()}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-300 text-white font-medium flex items-center gap-1"
              >
                <Send className="w-4 h-4" />
                Send
              </button>
            </div>
          </div>
          <p className="text-xs text-slate-400 mt-2 text-center">
            Press Enter to send • Type "Samajh nahi aaya" for simpler explanation
          </p>
        </div>
      </div>
    </div>
  )
}

export default function LearnPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full" />
      </div>
    }>
      <LearnContent />
    </Suspense>
  )
}
