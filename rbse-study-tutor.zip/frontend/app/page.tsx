import { SignedIn, SignedOut, SignInButton } from "@clerk/nextjs"
import Link from "next/link"
import { motion } from "framer-motion"
import { BookOpen, Brain, Sparkles, Target, Zap, Heart, GraduationCap, ArrowRight } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white overflow-hidden">
      {/* Floating particles background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-white/10 rounded-full"
            initial={{ x: Math.random() * 100 + "%", y: Math.random() * 100 + "%" }}
            animate={{
              y: [null, Math.random() * 100 + "%"],
              x: [null, Math.random() * 100 + "%"],
            }}
            transition={{ duration: 20 + Math.random() * 10, repeat: Infinity, ease: "linear" }}
          />
        ))}
      </div>

      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-4 max-w-7xl mx-auto">
        <div className="flex items-center gap-2">
          <GraduationCap className="w-8 h-8 text-emerald-400" />
          <span className="text-xl font-bold">RBSE Tutor</span>
        </div>
        <div className="flex items-center gap-4">
          <SignedOut>
            <SignInButton>
              <button className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 transition-colors text-sm font-medium">
                Sign In
              </button>
            </SignInButton>
          </SignedOut>
          <SignedIn>
            <Link href="/dashboard" className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 transition-colors text-sm font-medium">
              Dashboard
            </Link>
          </SignedIn>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative z-10 px-6 py-20 max-w-7xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/20 text-emerald-300 text-sm mb-8">
            <Sparkles className="w-4 h-4" />
            <span>AI-Powered Personal Tutor for Class 12</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Your <span className="text-emerald-400">Elder Brother</span>
            <br />
            Who Teaches You Everything
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-4">
            Simple Hindi explanations. Real-life examples. Memory tricks.
            <br />
            <span className="text-emerald-300">Board exam ready. Zero to hero.</span>
          </p>
          <p className="text-lg text-slate-400 max-w-xl mx-auto mb-10 hindi-text">
            "जैसे बड़ा भाई बैठके पढ़ाता है - बस वैसे ही"
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <SignedOut>
              <SignInButton>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-lg flex items-center gap-2 shadow-lg shadow-emerald-500/25"
                >
                  Start Learning Free
                  <ArrowRight className="w-5 h-5" />
                </motion.button>
              </SignInButton>
            </SignedOut>
            <SignedIn>
              <Link href="/dashboard">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-lg flex items-center gap-2 shadow-lg shadow-emerald-500/25"
                >
                  Go to Dashboard
                  <ArrowRight className="w-5 h-5" />
                </motion.button>
              </Link>
            </SignedIn>
            <button className="px-8 py-4 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-lg border border-white/20">
              Watch Demo
            </button>
          </div>
        </motion.div>
      </section>

      {/* Features Grid */}
      <section className="relative z-10 px-6 py-20 max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {[
            { icon: Brain, title: "5 AI Teachers", desc: "Biology, Physics, Chemistry, Hindi, English - each with unique style", color: "bg-blue-500/20 text-blue-300" },
            { icon: BookOpen, title: "PDF to Brain", desc: "Upload textbooks. AI reads, understands, and teaches from them", color: "bg-amber-500/20 text-amber-300" },
            { icon: Target, title: "30-Min Sessions", desc: "Introduction → Concepts → Memory → Revision → Test. Structured learning", color: "bg-rose-500/20 text-rose-300" },
            { icon: Heart, title: "Never Gives Up", desc: ""Samajh nahi aaya?" AI simplifies again and again until you get it", color: "bg-emerald-500/20 text-emerald-300" },
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-6 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors"
            >
              <div className={`w-12 h-12 rounded-xl ${feature.color} flex items-center justify-center mb-4`}>
                <feature.icon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-slate-400 text-sm">{feature.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Subjects Section */}
      <section className="relative z-10 px-6 py-20 max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">All Subjects Covered</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {[
            { name: "Biology", hindi: "जीव विज्ञान", icon: "🧬", color: "from-green-500/20 to-emerald-500/20", border: "border-green-500/30" },
            { name: "Physics", hindi: "भौतिक विज्ञान", icon: "⚡", color: "from-blue-500/20 to-cyan-500/20", border: "border-blue-500/30" },
            { name: "Chemistry", hindi: "रसायन विज्ञान", icon: "⚗️", color: "from-amber-500/20 to-orange-500/20", border: "border-amber-500/30" },
            { name: "Hindi", hindi: "हिंदी", icon: "📖", color: "from-pink-500/20 to-rose-500/20", border: "border-pink-500/30" },
            { name: "English", hindi: "अंग्रेज़ी", icon: "📝", color: "from-violet-500/20 to-purple-500/20", border: "border-violet-500/30" },
          ].map((subject, i) => (
            <motion.div
              key={i}
              whileHover={{ scale: 1.05, y: -5 }}
              className={`p-6 rounded-2xl bg-gradient-to-br ${subject.color} border ${subject.border} text-center`}
            >
              <div className="text-4xl mb-3">{subject.icon}</div>
              <h3 className="font-semibold text-lg">{subject.name}</h3>
              <p className="text-sm text-slate-400 hindi-text">{subject.hindi}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* How it Works */}
      <section className="relative z-10 px-6 py-20 max-w-5xl mx-auto">
        <h2 className="text-3xl font-bold text-center mb-12">How Bhaiya Teaches You</h2>
        <div className="space-y-8">
          {[
            { step: "1", title: "Chapter Introduction", time: "5 min", desc: ""Ye chapter kya hai? Kyun padhna hai? Real life me kaam kaise aata hai?"" },
            { step: "2", title: "Concept Teaching", time: "15 min", desc: "Simple Hindi + English. Stories. Analogies. Diagrams. NCERT lines." },
            { step: "3", title: "Memory Mode", time: "5 min", desc: "Mnemonics, tricks, cheat codes - jo yaad rahe exam tak" },
            { step: "4", title: "Quick Revision", time: "3 min", desc: "Key points, definitions, formula sheet - ek jagah sab kuch" },
            { step: "5", title: "Test Yourself", time: "2 min", desc: "5 easy + 5 medium + 5 board questions. Galat hua? Dobara samjhata hai" },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="flex items-start gap-4 p-4 rounded-xl bg-white/5 border border-white/10"
            >
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold shrink-0">
                {item.step}
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold">{item.title}</h3>
                  <span className="text-xs px-2 py-1 rounded-full bg-white/10 text-slate-300">{item.time}</span>
                </div>
                <p className="text-slate-400 text-sm">{item.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA Footer */}
      <section className="relative z-10 px-6 py-20 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <h2 className="text-3xl font-bold mb-4">Ready to Top Your Board Exams?</h2>
          <p className="text-slate-400 mb-8">
            Join thousands of students who learned with their AI Bhaiya.
            <br />
            Free forever. No credit card needed.
          </p>
          <SignedOut>
            <SignInButton>
              <button className="px-8 py-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-lg shadow-lg shadow-emerald-500/25">
                Start Learning Now - It's Free! 🚀
              </button>
            </SignInButton>
          </SignedOut>
          <SignedIn>
            <Link href="/dashboard">
              <button className="px-8 py-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-lg shadow-lg shadow-emerald-500/25">
                Continue Learning 🚀
              </button>
            </Link>
          </SignedIn>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/10 py-8 text-center text-slate-500 text-sm">
        <p>Made with ❤️ for every student who dreams big</p>
        <p className="mt-2">RBSE Class 12 Science & Humanities | AI Tutor</p>
      </footer>
    </div>
  )
}
