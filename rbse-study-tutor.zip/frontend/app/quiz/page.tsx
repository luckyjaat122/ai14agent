"use client"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { 
  CheckCircle, 
  XCircle, 
  ArrowRight, 
  ArrowLeft,
  Trophy,
  RotateCcw,
  BookOpen,
  Lightbulb
} from "lucide-react"
import { getSubjectById, getChapterById } from "@/lib/subjects"
import { useAppStore } from "@/hooks/useStore"
import { generateQuiz } from "@/lib/api"
import { cn } from "@/lib/utils"
import confetti from "canvas-confetti"

function QuizContent() {
  const searchParams = useSearchParams()
  const subjectId = searchParams.get("subject") || "biology"
  const chapterId = searchParams.get("chapter") || "bio-1"

  const [questions, setQuestions] = useState<any[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showExplanation, setShowExplanation] = useState(false)
  const [score, setScore] = useState(0)
  const [isCompleted, setIsCompleted] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [answers, setAnswers] = useState<Record<number, number>>({})

  const subject = getSubjectById(subjectId)
  const chapter = getChapterById(chapterId)

  useEffect(() => {
    loadQuiz()
  }, [])

  const loadQuiz = async () => {
    setIsLoading(true)
    try {
      const response = await generateQuiz({
        subjectId,
        chapterId,
        difficulty: "mixed",
        count: 15,
      })
      setQuestions(response.questions)
    } catch (error) {
      // Fallback questions
      setQuestions([
        {
          id: "1",
          question: `What is the main topic of ${chapter?.name}?`,
          questionHindi: `${chapter?.nameHindi} ka mukhya vishay kya hai?`,
          options: [chapter?.topics[0] || "Topic A", "Random Option", "Wrong Option", "Another Wrong"],
          correctAnswer: 0,
          explanation: `The main topic is ${chapter?.topics[0]}. This is fundamental to understanding the chapter.`,
          difficulty: "easy",
          marks: 1,
        },
        {
          id: "2",
          question: "Which of the following is NOT related to this chapter?",
          options: ["Related concept", "Another related", "Unrelated topic", "Also related"],
          correctAnswer: 2,
          explanation: "The unrelated topic doesn't belong to this chapter's scope.",
          difficulty: "medium",
          marks: 2,
        },
        {
          id: "3",
          question: "Explain the importance of this chapter in real life.",
          options: ["No importance", "Some importance", "Very important", "Extremely important"],
          correctAnswer: 3,
          explanation: "This chapter has extremely important real-life applications.",
          difficulty: "hard",
          marks: 3,
        },
      ])
    }
    setIsLoading(false)
  }

  const handleAnswer = (index: number) => {
    if (showExplanation) return
    setSelectedAnswer(index)
    setAnswers({ ...answers, [currentIndex]: index })

    if (index === questions[currentIndex].correctAnswer) {
      setScore(score + questions[currentIndex].marks)
    }
    setShowExplanation(true)
  }

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1)
      setSelectedAnswer(null)
      setShowExplanation(false)
    } else {
      setIsCompleted(true)
      if (score / questions.reduce((a, q) => a + q.marks, 0) > 0.7) {
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } })
      }
    }
  }

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1)
      setSelectedAnswer(answers[currentIndex - 1] ?? null)
      setShowExplanation(true)
    }
  }

  const handleRestart = () => {
    setCurrentIndex(0)
    setSelectedAnswer(null)
    setShowExplanation(false)
    setScore(0)
    setIsCompleted(false)
    setAnswers({})
    loadQuiz()
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full mx-auto mb-4" />
          <p className="text-slate-600">Generating quiz questions...</p>
          <p className="text-sm text-slate-400 hindi-text">सवाल तैयार हो रहे हैं</p>
        </div>
      </div>
    )
  }

  if (isCompleted) {
    const totalMarks = questions.reduce((a, q) => a + q.marks, 0)
    const percentage = Math.round((score / totalMarks) * 100)

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center"
        >
          <div className="text-6xl mb-4">
            {percentage >= 70 ? "🎉" : percentage >= 50 ? "👍" : "💪"}
          </div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">
            {percentage >= 70 ? "Excellent!" : percentage >= 50 ? "Good Job!" : "Keep Practicing!"}
          </h2>
          <p className="text-slate-600 mb-6">
            You scored {score} out of {totalMarks} marks ({percentage}%)
          </p>

          <div className="bg-slate-50 rounded-xl p-4 mb-6">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-600">Correct Answers</span>
              <span className="font-semibold text-emerald-600">
                {Object.entries(answers).filter(([i, a]) => a === questions[Number(i)].correctAnswer).length}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-600">Wrong Answers</span>
              <span className="font-semibold text-red-600">
                {Object.entries(answers).filter(([i, a]) => a !== questions[Number(i)].correctAnswer).length}
              </span>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              onClick={handleRestart}
              className="flex-1 px-4 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              Try Again
            </button>
          </div>
        </motion.div>
      </div>
    )
  }

  const currentQuestion = questions[currentIndex]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{subject?.icon}</span>
            <div>
              <h1 className="font-semibold text-slate-900">Quiz: {chapter?.name}</h1>
              <p className="text-xs text-slate-500">Question {currentIndex + 1} of {questions.length}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm font-semibold text-slate-900">Score: {score}</p>
            <p className="text-xs text-slate-500">{currentQuestion?.difficulty}</p>
          </div>
        </div>

        {/* Progress */}
        <div className="h-2 bg-slate-200 rounded-full mb-8 overflow-hidden">
          <motion.div
            className="h-full bg-emerald-500 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
          />
        </div>

        {/* Question */}
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl shadow-lg p-6 mb-6"
        >
          <div className="flex items-start gap-3 mb-6">
            <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-700 text-sm font-medium">
              Q{currentIndex + 1}
            </span>
            <div>
              <h3 className="text-lg font-semibold text-slate-900">{currentQuestion?.question}</h3>
              {currentQuestion?.questionHindi && (
                <p className="text-sm text-slate-600 hindi-text mt-1">{currentQuestion.questionHindi}</p>
              )}
            </div>
          </div>

          {/* Options */}
          <div className="space-y-3">
            {currentQuestion?.options.map((option: string, index: number) => (
              <motion.button
                key={index}
                whileHover={!showExplanation ? { scale: 1.02 } : {}}
                whileTap={!showExplanation ? { scale: 0.98 } : {}}
                onClick={() => handleAnswer(index)}
                disabled={showExplanation}
                className={cn(
                  "w-full p-4 rounded-xl border-2 text-left transition-all",
                  !showExplanation && "border-slate-200 hover:border-emerald-300 bg-white",
                  showExplanation && index === currentQuestion.correctAnswer && "border-emerald-500 bg-emerald-50",
                  showExplanation && selectedAnswer === index && index !== currentQuestion.correctAnswer && "border-red-500 bg-red-50",
                  showExplanation && selectedAnswer !== index && index !== currentQuestion.correctAnswer && "border-slate-200 opacity-50",
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium",
                    !showExplanation && "bg-slate-100 text-slate-600",
                    showExplanation && index === currentQuestion.correctAnswer && "bg-emerald-500 text-white",
                    showExplanation && selectedAnswer === index && index !== currentQuestion.correctAnswer && "bg-red-500 text-white",
                    showExplanation && selectedAnswer !== index && index !== currentQuestion.correctAnswer && "bg-slate-100 text-slate-400",
                  )}>
                    {String.fromCharCode(65 + index)}
                  </div>
                  <span className="text-slate-700">{option}</span>
                  {showExplanation && index === currentQuestion.correctAnswer && (
                    <CheckCircle className="w-5 h-5 text-emerald-500 ml-auto" />
                  )}
                  {showExplanation && selectedAnswer === index && index !== currentQuestion.correctAnswer && (
                    <XCircle className="w-5 h-5 text-red-500 ml-auto" />
                  )}
                </div>
              </motion.button>
            ))}
          </div>

          {/* Explanation */}
          <AnimatePresence>
            {showExplanation && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                className="mt-6 p-4 rounded-xl bg-blue-50 border border-blue-200"
              >
                <div className="flex items-start gap-2">
                  <Lightbulb className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-blue-900 mb-1">Explanation:</p>
                    <p className="text-sm text-blue-800">{currentQuestion?.explanation}</p>
                    {currentQuestion?.explanationHindi && (
                      <p className="text-sm text-blue-700 hindi-text mt-2">{currentQuestion.explanationHindi}</p>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Navigation */}
        <div className="flex justify-between">
          <button
            onClick={handlePrevious}
            disabled={currentIndex === 0}
            className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-700 font-medium flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Previous
          </button>
          <button
            onClick={handleNext}
            disabled={!showExplanation}
            className="px-6 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-600 disabled:bg-slate-300 text-white font-medium flex items-center gap-2"
          >
            {currentIndex === questions.length - 1 ? "Finish" : "Next"}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  )
}

export default function QuizPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-emerald-500 border-t-transparent rounded-full" />
      </div>
    }>
      <QuizContent />
    </Suspense>
  )
}
