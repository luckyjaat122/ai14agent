"use client"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import { motion } from "framer-motion"
import { 
  FileText, 
  Moon, 
  Star, 
  Calculator,
  Download,
  Copy,
  Check
} from "lucide-react"
import { getSubjectById, getChapterById } from "@/lib/subjects"
import { generateRevision } from "@/lib/api"
import { cn } from "@/lib/utils"
import ReactMarkdown from "react-markdown"
import remarkGfm from "remark-gfm"

function RevisionContent() {
  const searchParams = useSearchParams()
  const subjectId = searchParams.get("subject") || "biology"
  const chapterId = searchParams.get("chapter") || "bio-1"

  const [selectedType, setSelectedType] = useState<"one-page" | "last-night" | "important-questions" | "formula-sheet">("one-page")
  const [content, setContent] = useState("")
  const [contentHindi, setContentHindi] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [copied, setCopied] = useState(false)

  const subject = getSubjectById(subjectId)
  const chapter = getChapterById(chapterId)

  const types = [
    { id: "one-page" as const, name: "One Page Notes", hindi: "एक पेज के नोट्स", icon: FileText, color: "bg-blue-500", desc: "Complete chapter in one page" },
    { id: "last-night" as const, name: "Last Night Notes", hindi: "आखिरी रात के नोट्स", icon: Moon, color: "bg-indigo-500", desc: "Quick revision before exam" },
    { id: "important-questions" as const, name: "Important Questions", hindi: "महत्वपूर्ण सवाल", icon: Star, color: "bg-amber-500", desc: "Most likely board questions" },
    { id: "formula-sheet" as const, name: "Formula Sheet", hindi: "सूत्र सूची", icon: Calculator, color: "bg-emerald-500", desc: "All formulas at one place" },
  ]

  const loadRevision = async () => {
    setIsLoading(true)
    try {
      const response = await generateRevision({
        subjectId,
        chapterId,
        type: selectedType,
      })
      setContent(response.content)
      setContentHindi(response.contentHindi || "")
    } catch (error) {
      const fallbackContent: Record<string, string> = {
        "one-page": `# 📄 One Page Notes: ${chapter?.name}

## Key Concepts
- ${chapter?.topics?.join("
- ") || "Main topics"}

## Important Definitions
1. **Definition 1**: Meaning here
2. **Definition 2**: Meaning here

## Formulas (if any)
\\`\\`\\`
Formula 1 = ...
Formula 2 = ...
\\`\\`\\`

## Diagrams to Remember
- Diagram 1: Description
- Diagram 2: Description

## NCERT Important Lines
> "Important quote from NCERT"

## Quick Memory Trick
Use mnemonic: **MRS GREN** or create your own!`,
        "last-night": `# 🌙 Last Night Revision: ${chapter?.name}

## ⚡ 5 Minute Quick Read

**Must Know (100% aayega):**
1. Point 1
2. Point 2
3. Point 3

**Formulas (ratt lo):**
- Formula 1
- Formula 2

**Diagrams (banane hain):**
1. Diagram 1
2. Diagram 2

**Definitions (exact words):**
- Definition 1
- Definition 2

## 🎯 Predicted Questions
1. Long answer (5 marks)
2. Short answer (3 marks)
3. MCQ (1 mark)

**All the best! 🍀**`,
        "important-questions": `# ⭐ Important Questions: ${chapter?.name}

## 5 Marks Questions (Long Answer)
1. Explain ${chapter?.topics?.[0] || "main topic"} in detail with diagram.
2. Describe the process of ${chapter?.topics?.[1] || "secondary topic"}.

## 3 Marks Questions (Short Answer)
3. What is ${chapter?.topics?.[0]}? Write its importance.
4. Differentiate between...

## 2 Marks Questions (Very Short)
5. Define ${chapter?.topics?.[0]}.
6. Write two examples of...

## 1 Mark Questions (MCQ/Fill ups)
7. ${chapter?.topics?.[0]} was discovered by ______.
8. The unit of ______ is ______.

## Answers Hints
- Use diagrams wherever possible
- Write in points
- Underline key terms`,
        "formula-sheet": `# 📐 Formula Sheet: ${chapter?.name}

## Important Formulas

### Formula 1
\\`\\`\\`
F = ma
\\`\\`\\`
**Where:** F = Force, m = mass, a = acceleration

### Formula 2
\\`\\`\\`
E = mc²
\\`\\`\\`
**Where:** E = Energy, m = mass, c = speed of light

## Units to Remember
| Quantity | Unit | Symbol |
|----------|------|--------|
| Force | Newton | N |
| Energy | Joule | J |

## Constants
- g = 9.8 m/s²
- c = 3 × 10⁸ m/s

## Memory Trick
**F = ma** → "Force = Maa (Mother) ka **A**ashirwad"`,
      }
      setContent(fallbackContent[selectedType] || "Content loading...")
      setContentHindi("")
    }
    setIsLoading(false)
  }

  useEffect(() => {
    loadRevision()
  }, [selectedType])

  const handleCopy = () => {
    navigator.clipboard.writeText(content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleDownload = () => {
    const blob = new Blob([content], { type: "text/markdown" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${chapter?.name}-${selectedType}.md`
    a.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <span className="text-4xl mb-2 block">{subject?.icon}</span>
          <h1 className="text-2xl font-bold text-slate-900">Revision Notes</h1>
          <p className="text-slate-600">{chapter?.name}</p>
          <p className="text-sm text-slate-500 hindi-text">{chapter?.nameHindi}</p>
        </div>

        {/* Type Selection */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
          {types.map((type) => (
            <button
              key={type.id}
              onClick={() => setSelectedType(type.id)}
              className={cn(
                "p-4 rounded-xl border-2 text-left transition-all",
                selectedType === type.id
                  ? `border-${type.color.replace("bg-", "")}-500 bg-${type.color.replace("bg-", "")}-50`
                  : "border-slate-200 bg-white hover:border-slate-300"
              )}
            >
              <type.icon className={cn("w-6 h-6 mb-2", type.color.replace("bg-", "text-"))} />
              <h3 className="font-semibold text-sm text-slate-900">{type.name}</h3>
              <p className="text-xs text-slate-500 hindi-text">{type.hindi}</p>
              <p className="text-xs text-slate-400 mt-1">{type.desc}</p>
            </button>
          ))}
        </div>

        {/* Content */}
        <motion.div
          key={selectedType}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-lg border border-slate-200 overflow-hidden"
        >
          {/* Toolbar */}
          <div className="flex items-center justify-between px-6 py-3 border-b border-slate-100 bg-slate-50">
            <span className="text-sm font-medium text-slate-600">
              {types.find(t => t.id === selectedType)?.name}
            </span>
            <div className="flex gap-2">
              <button
                onClick={handleCopy}
                className="p-2 rounded-lg hover:bg-white text-slate-500 hover:text-slate-700 transition-colors"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
              <button
                onClick={handleDownload}
                className="p-2 rounded-lg hover:bg-white text-slate-500 hover:text-slate-700 transition-colors"
              >
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Note Content */}
          <div className="p-6 paper-note">
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin w-8 h-8 border-4 border-amber-500 border-t-transparent rounded-full" />
              </div>
            ) : (
              <div className="prose prose-sm max-w-none">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {content}
                </ReactMarkdown>
                {contentHindi && (
                  <div className="mt-6 pt-6 border-t-2 border-dashed border-slate-200">
                    <p className="text-sm font-semibold text-slate-500 mb-2">Hindi Version:</p>
                    <div className="hindi-text text-slate-700">
                      <ReactMarkdown remarkPlugins={[remarkGfm]}>
                        {contentHindi}
                      </ReactMarkdown>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  )
}

export default function RevisionPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-amber-500 border-t-transparent rounded-full" />
      </div>
    }>
      <RevisionContent />
    </Suspense>
  )
}
