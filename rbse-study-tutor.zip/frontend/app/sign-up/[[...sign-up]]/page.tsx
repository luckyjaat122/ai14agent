import { SignUp } from "@clerk/nextjs"
import { GraduationCap } from "lucide-react"

export default function SignUpPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-4">
            <GraduationCap className="w-8 h-8 text-emerald-400" />
            <span className="text-xl font-bold text-white">RBSE Tutor</span>
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Join the Family!</h1>
          <p className="text-slate-400">Create your account and start learning today</p>
        </div>
        <SignUp
          appearance={{
            elements: {
              card: "bg-white/10 border border-white/20 shadow-xl",
              headerTitle: "text-white",
              headerSubtitle: "text-slate-400",
              socialButtonsBlockButton: "bg-white/10 border-white/20 text-white hover:bg-white/20",
              formFieldLabel: "text-slate-300",
              formFieldInput: "bg-white/10 border-white/20 text-white placeholder:text-slate-500",
              formButtonPrimary: "bg-emerald-500 hover:bg-emerald-600",
              footerActionText: "text-slate-400",
              footerActionLink: "text-emerald-400 hover:text-emerald-300",
              formFieldErrorText: "text-red-400",
              alertText: "text-red-400",
              dividerLine: "bg-white/20",
              dividerText: "text-slate-400",
            },
          }}
        />
      </div>
    </div>
  )
}
