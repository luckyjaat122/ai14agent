import { create } from "zustand"
import { persist } from "zustand/middleware"
import { 
  TeachingSession, 
  Flashcard, 
  Quiz, 
  RevisionNote, 
  DoubtMessage,
  PDFUpload,
  UserProgress 
} from "@/types"
import { generateId } from "@/lib/utils"

interface AppState {
  // Teaching sessions
  activeSession: TeachingSession | null
  sessionHistory: TeachingSession[]
  startSession: (chapterId: string, subjectId: string) => TeachingSession
  addMessage: (message: Omit<TeachingSession["messages"][0], "id" | "timestamp">) => void
  endSession: () => void
  pauseSession: () => void
  resumeSession: () => void

  // Flashcards
  flashcards: Flashcard[]
  addFlashcards: (cards: Omit<Flashcard, "id" | "isMastered" | "reviewCount" | "lastReviewed">[]) => void
  markFlashcardMastered: (id: string) => void
  reviewFlashcard: (id: string) => void

  // Quizzes
  quizzes: Quiz[]
  addQuiz: (quiz: Omit<Quiz, "id" | "completedAt">) => void
  completeQuiz: (id: string, score: number) => void

  // Revision notes
  revisionNotes: RevisionNote[]
  addRevisionNote: (note: Omit<RevisionNote, "id" | "generatedAt">) => void

  // Doubts
  doubts: DoubtMessage[]
  addDoubt: (doubt: Omit<DoubtMessage, "id" | "timestamp" | "isResolved" | "simplifiedCount">) => void
  resolveDoubt: (id: string) => void
  simplifyDoubt: (id: string, answer: string) => void

  // PDF uploads
  uploads: PDFUpload[]
  addUpload: (upload: Omit<PDFUpload, "id" | "uploadedAt">) => void
  updateUploadProgress: (id: string, progress: number) => void
  completeUpload: (id: string, chapters: string[]) => void

  // User progress
  progress: UserProgress[]
  updateProgress: (subjectId: string, updates: Partial<UserProgress>) => void

  // UI state
  currentSubject: string | null
  currentChapter: string | null
  setCurrentSubject: (id: string | null) => void
  setCurrentChapter: (id: string | null) => void
  isLoading: boolean
  setIsLoading: (loading: boolean) => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial state
      activeSession: null,
      sessionHistory: [],
      flashcards: [],
      quizzes: [],
      revisionNotes: [],
      doubts: [],
      uploads: [],
      progress: [],
      currentSubject: null,
      currentChapter: null,
      isLoading: false,

      // Teaching session actions
      startSession: (chapterId, subjectId) => {
        const session: TeachingSession = {
          id: generateId(),
          chapterId,
          subjectId,
          currentPart: 1,
          totalParts: 5,
          messages: [],
          startedAt: new Date().toISOString(),
          status: "active",
        }
        set({ activeSession: session })
        return session
      },

      addMessage: (message) => {
        const { activeSession } = get()
        if (!activeSession) return
        const newMessage = {
          ...message,
          id: generateId(),
          timestamp: new Date().toISOString(),
        }
        set({
          activeSession: {
            ...activeSession,
            messages: [...activeSession.messages, newMessage],
          },
        })
      },

      endSession: () => {
        const { activeSession, sessionHistory } = get()
        if (!activeSession) return
        const completedSession = {
          ...activeSession,
          status: "completed" as const,
        }
        set({
          activeSession: null,
          sessionHistory: [...sessionHistory, completedSession],
        })
      },

      pauseSession: () => {
        const { activeSession } = get()
        if (!activeSession) return
        set({
          activeSession: { ...activeSession, status: "paused" },
        })
      },

      resumeSession: () => {
        const { activeSession } = get()
        if (!activeSession) return
        set({
          activeSession: { ...activeSession, status: "active" },
        })
      },

      // Flashcard actions
      addFlashcards: (cards) => {
        const newCards: Flashcard[] = cards.map((card) => ({
          ...card,
          id: generateId(),
          isMastered: false,
          reviewCount: 0,
          lastReviewed: null,
        }))
        set({ flashcards: [...get().flashcards, ...newCards] })
      },

      markFlashcardMastered: (id) => {
        set({
          flashcards: get().flashcards.map((card) =>
            card.id === id ? { ...card, isMastered: true } : card
          ),
        })
      },

      reviewFlashcard: (id) => {
        set({
          flashcards: get().flashcards.map((card) =>
            card.id === id
              ? { ...card, reviewCount: card.reviewCount + 1, lastReviewed: new Date().toISOString() }
              : card
          ),
        })
      },

      // Quiz actions
      addQuiz: (quiz) => {
        const newQuiz: Quiz = {
          ...quiz,
          id: generateId(),
          completedAt: null,
        }
        set({ quizzes: [...get().quizzes, newQuiz] })
      },

      completeQuiz: (id, score) => {
        set({
          quizzes: get().quizzes.map((quiz) =>
            quiz.id === id
              ? { ...quiz, userScore: score, completedAt: new Date().toISOString() }
              : quiz
          ),
        })
      },

      // Revision note actions
      addRevisionNote: (note) => {
        const newNote: RevisionNote = {
          ...note,
          id: generateId(),
          generatedAt: new Date().toISOString(),
        }
        set({ revisionNotes: [...get().revisionNotes, newNote] })
      },

      // Doubt actions
      addDoubt: (doubt) => {
        const newDoubt: DoubtMessage = {
          ...doubt,
          id: generateId(),
          timestamp: new Date().toISOString(),
          isResolved: false,
          simplifiedCount: 0,
        }
        set({ doubts: [...get().doubts, newDoubt] })
      },

      resolveDoubt: (id) => {
        set({
          doubts: get().doubts.map((d) =>
            d.id === id ? { ...d, isResolved: true } : d
          ),
        })
      },

      simplifyDoubt: (id, answer) => {
        set({
          doubts: get().doubts.map((d) =>
            d.id === id
              ? { ...d, answer, simplifiedCount: d.simplifiedCount + 1 }
              : d
          ),
        })
      },

      // Upload actions
      addUpload: (upload) => {
        const newUpload: PDFUpload = {
          ...upload,
          id: generateId(),
          uploadedAt: new Date().toISOString(),
        }
        set({ uploads: [...get().uploads, newUpload] })
      },

      updateUploadProgress: (id, progress) => {
        set({
          uploads: get().uploads.map((u) =>
            u.id === id ? { ...u, progress } : u
          ),
        })
      },

      completeUpload: (id, chapters) => {
        set({
          uploads: get().uploads.map((u) =>
            u.id === id
              ? { ...u, uploadStatus: "completed", chaptersDetected: chapters }
              : u
          ),
        })
      },

      // Progress actions
      updateProgress: (subjectId, updates) => {
        const { progress } = get()
        const existing = progress.find((p) => p.subjectId === subjectId)
        if (existing) {
          set({
            progress: progress.map((p) =>
              p.subjectId === subjectId ? { ...p, ...updates } : p
            ),
          })
        } else {
          set({
            progress: [
              ...progress,
              {
                subjectId,
                totalChapters: 0,
                completedChapters: 0,
                totalStudyTime: 0,
                quizAverage: 0,
                flashcardsMastered: 0,
                streakDays: 0,
                lastStudied: new Date().toISOString(),
                ...updates,
              },
            ],
          })
        }
      },

      // UI actions
      setCurrentSubject: (id) => set({ currentSubject: id }),
      setCurrentChapter: (id) => set({ currentChapter: id }),
      setIsLoading: (loading) => set({ isLoading: loading }),
    }),
    {
      name: "rbse-study-tutor-store",
      partialize: (state) => ({
        sessionHistory: state.sessionHistory,
        flashcards: state.flashcards,
        quizzes: state.quizzes,
        revisionNotes: state.revisionNotes,
        doubts: state.doubts,
        uploads: state.uploads,
        progress: state.progress,
      }),
    }
  )
)
