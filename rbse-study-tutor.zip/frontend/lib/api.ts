import axios from "axios"

const API_BASE = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000"

const api = axios.create({
  baseURL: API_BASE,
  headers: {
    "Content-Type": "application/json",
  },
  timeout: 60000,
})

// Add auth token if available
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("clerk-token")
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export interface ChatRequest {
  message: string
  subjectId: string
  chapterId?: string
  sessionId?: string
  context?: string
  isDoubt?: boolean
  simplifyLevel?: number
  ragChunks?: { text: string; score: number }[]
}

export interface ChatResponse {
  message: string
  messageHindi?: string
  type: string
  hasDiagram?: boolean
  diagramUrl?: string
  suggestedQuestions?: string[]
  ragUsed?: boolean
}

export interface LearnRequest {
  subjectId: string
  chapterId: string
  part: "introduction" | "concept" | "memory" | "revision" | "testing"
  previousMessages?: { role: string; content: string }[]
  conceptIndex?: number
}

export interface QuizRequest {
  subjectId: string
  chapterId: string
  difficulty: "easy" | "medium" | "hard" | "mixed"
  count?: number
}

export interface FlashcardRequest {
  subjectId: string
  chapterId: string
  count?: number
}

export interface RevisionRequest {
  subjectId: string
  chapterId: string
  type: "one-page" | "last-night" | "important-questions" | "formula-sheet"
}

export interface UploadPDFRequest {
  file: File
  subjectId: string
}

export async function sendChatMessage(req: ChatRequest): Promise<ChatResponse> {
  const response = await api.post("/api/chat", req)
  return response.data
}

export async function startLearning(req: LearnRequest): Promise<ChatResponse> {
  const response = await api.post("/api/learn", req)
  return response.data
}

export async function generateQuiz(req: QuizRequest): Promise<{ questions: any[] }> {
  const response = await api.post("/api/quiz/generate", req)
  return response.data
}

export async function generateFlashcards(req: FlashcardRequest): Promise<{ flashcards: any[] }> {
  const response = await api.post("/api/flashcards/generate", req)
  return response.data
}

export async function generateRevision(req: RevisionRequest): Promise<{ content: string; contentHindi?: string }> {
  const response = await api.post("/api/revision/generate", req)
  return response.data
}

export async function uploadPDF(file: File, subjectId: string): Promise<{ uploadId: string; status: string }> {
  const formData = new FormData()
  formData.append("file", file)
  formData.append("subjectId", subjectId)

  const response = await api.post("/api/upload/pdf", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  })
  return response.data
}

export async function getRAGChunks(query: string, subjectId: string, chapterId?: string): Promise<{ chunks: any[] }> {
  const response = await api.post("/api/rag/retrieve", {
    query,
    subjectId,
    chapterId,
    topK: 5,
  })
  return response.data
}

export async function getUploadStatus(uploadId: string): Promise<{ status: string; progress: number; chapters?: string[] }> {
  const response = await api.get(`/api/upload/status/${uploadId}`)
  return response.data
}

export default api
