import { Subject, Chapter, AgentConfig } from "@/types"

export const SUBJECTS: Subject[] = [
  {
    id: "biology",
    name: "Biology",
    nameHindi: "जीव विज्ञान",
    color: "biology",
    icon: "🧬",
    description: "Life processes, genetics, ecology, and human physiology",
    descriptionHindi: "जीव प्रक्रम, आनुवंशिकी, परिस्थितिकी और मानव शरीर विज्ञान",
    totalChapters: 16,
    completedChapters: 0,
  },
  {
    id: "physics",
    name: "Physics",
    nameHindi: "भौतिक विज्ञान",
    color: "physics",
    icon: "⚡",
    description: "Electricity, magnetism, optics, and modern physics",
    descriptionHindi: "विद्युत, चुंबकत्व, प्रकाशिकी और आधुनिक भौतिकी",
    totalChapters: 15,
    completedChapters: 0,
  },
  {
    id: "chemistry",
    name: "Chemistry",
    nameHindi: "रसायन विज्ञान",
    color: "chemistry",
    icon: "⚗️",
    description: "Organic, inorganic, and physical chemistry",
    descriptionHindi: "कार्बनिक, अकार्बनिक और भौतिक रसायन विज्ञान",
    totalChapters: 16,
    completedChapters: 0,
  },
  {
    id: "hindi",
    name: "Hindi",
    nameHindi: "हिंदी",
    color: "hindi",
    icon: "📖",
    description: "Prose, poetry, grammar, and writing skills",
    descriptionHindi: "गद्य, पद्य, व्याकरण और लेखन कौशल",
    totalChapters: 22,
    completedChapters: 0,
  },
  {
    id: "english",
    name: "English",
    nameHindi: "अंग्रेज़ी",
    color: "english",
    icon: "📝",
    description: "Literature, grammar, and communication skills",
    descriptionHindi: "साहित्य, व्याकरण और संचार कौशल",
    totalChapters: 20,
    completedChapters: 0,
  },
]

export const BIOLOGY_CHAPTERS: Chapter[] = [
  { id: "bio-1", subjectId: "biology", name: "Reproduction in Organisms", nameHindi: "जीवों में जनन", number: 1, description: "Asexual and sexual reproduction methods", topics: ["Asexual reproduction", "Sexual reproduction", "Life cycles"], difficulty: "easy", estimatedTime: 45, isCompleted: false, progress: 0 },
  { id: "bio-2", subjectId: "biology", name: "Sexual Reproduction in Flowering Plants", nameHindi: "पुष्पी पौधों में लैंगिक जनन", number: 2, description: "Flower structure, pollination, fertilization", topics: ["Flower parts", "Pollination types", "Double fertilization"], difficulty: "medium", estimatedTime: 60, isCompleted: false, progress: 0 },
  { id: "bio-3", subjectId: "biology", name: "Human Reproduction", nameHindi: "मानव जनन", number: 3, description: "Male and female reproductive systems", topics: ["Male reproductive system", "Female reproductive system", "Menstrual cycle", "Pregnancy"], difficulty: "medium", estimatedTime: 55, isCompleted: false, progress: 0 },
  { id: "bio-4", subjectId: "biology", name: "Reproductive Health", nameHindi: "प्रजनन स्वास्थ्य", number: 4, description: "Contraception, STDs, and health awareness", topics: ["Contraceptive methods", "STDs", "Infertility"], difficulty: "easy", estimatedTime: 40, isCompleted: false, progress: 0 },
  { id: "bio-5", subjectId: "biology", name: "Principles of Inheritance and Variation", nameHindi: "वंशागति और विविधता के सिद्धांत", number: 5, description: "Mendel's laws, genetic disorders", topics: ["Mendel's experiments", "Law of segregation", "Law of independent assortment", "Genetic disorders"], difficulty: "hard", estimatedTime: 70, isCompleted: false, progress: 0 },
  { id: "bio-6", subjectId: "biology", name: "Molecular Basis of Inheritance", nameHindi: "वंशागति का आणविक आधार", number: 6, description: "DNA structure, replication, transcription, translation", topics: ["DNA structure", "DNA replication", "RNA types", "Protein synthesis"], difficulty: "hard", estimatedTime: 75, isCompleted: false, progress: 0 },
  { id: "bio-7", subjectId: "biology", name: "Evolution", nameHindi: "विकास", number: 7, description: "Origin of life, natural selection, speciation", topics: ["Origin of life", "Natural selection", "Adaptive radiation", "Human evolution"], difficulty: "medium", estimatedTime: 60, isCompleted: false, progress: 0 },
  { id: "bio-8", subjectId: "biology", name: "Human Health and Disease", nameHindi: "मानव स्वास्थ्य और रोग", number: 8, description: "Immunity, diseases, and health management", topics: ["Innate immunity", "Acquired immunity", "AIDS", "Cancer"], difficulty: "medium", estimatedTime: 55, isCompleted: false, progress: 0 },
  { id: "bio-9", subjectId: "biology", name: "Strategies for Enhancement in Food Production", nameHindi: "खाद्य उत्पादन में वृद्धि की रणनीतियाँ", number: 9, description: "Animal husbandry, plant breeding, tissue culture", topics: ["Animal breeding", "Plant breeding", "Tissue culture", "Biofortification"], difficulty: "easy", estimatedTime: 45, isCompleted: false, progress: 0 },
  { id: "bio-10", subjectId: "biology", name: "Microbes in Human Welfare", nameHindi: "मान कल्याण में सूक्ष्मजीव", number: 10, description: "Useful microbes, antibiotics, sewage treatment", topics: ["Microbes in household", "Antibiotics", "Fermentation", "Biogas"], difficulty: "easy", estimatedTime: 40, isCompleted: false, progress: 0 },
  { id: "bio-11", subjectId: "biology", name: "Biotechnology: Principles and Processes", nameHindi: "जैव प्रौद्योगिकी: सिद्धांत और प्रक्रम", number: 11, description: "Genetic engineering, recombinant DNA technology", topics: ["Restriction enzymes", "Cloning vectors", "PCR", "Gel electrophoresis"], difficulty: "hard", estimatedTime: 70, isCompleted: false, progress: 0 },
  { id: "bio-12", subjectId: "biology", name: "Biotechnology and its Applications", nameHindi: "जैव प्रौद्योगिकी और उसके उपयोग", number: 12, description: "GM crops, gene therapy, molecular diagnostics", topics: ["Bt cotton", "Gene therapy", "Insulin production", "DNA fingerprinting"], difficulty: "medium", estimatedTime: 55, isCompleted: false, progress: 0 },
  { id: "bio-13", subjectId: "biology", name: "Organisms and Populations", nameHindi: "जीव और समष्टियाँ", number: 13, description: "Population growth, interactions, adaptations", topics: ["Population growth", "Predation", "Competition", "Adaptations"], difficulty: "medium", estimatedTime: 50, isCompleted: false, progress: 0 },
  { id: "bio-14", subjectId: "biology", name: "Ecosystem", nameHindi: "पारिस्थितिकी तंत्र", number: 14, description: "Food chains, energy flow, ecological pyramids", topics: ["Food chain", "Food web", "Energy flow", "Ecological pyramids"], difficulty: "medium", estimatedTime: 50, isCompleted: false, progress: 0 },
  { id: "bio-15", subjectId: "biology", name: "Biodiversity and Conservation", nameHindi: "जैव विविधता और संरक्षण", number: 15, description: "Biodiversity types, hotspots, conservation methods", topics: ["Biodiversity types", "Hotspots", "In-situ conservation", "Ex-situ conservation"], difficulty: "easy", estimatedTime: 40, isCompleted: false, progress: 0 },
  { id: "bio-16", subjectId: "biology", name: "Environmental Issues", nameHindi: "पर्यावरणीय समस्याएँ", number: 16, description: "Pollution, global warming, ozone depletion", topics: ["Air pollution", "Water pollution", "Global warming", "Ozone depletion"], difficulty: "easy", estimatedTime: 45, isCompleted: false, progress: 0 },
]

export const PHYSICS_CHAPTERS: Chapter[] = [
  { id: "phy-1", subjectId: "physics", name: "Electric Charges and Fields", nameHindi: "विद्युत आवेश और क्षेत्र", number: 1, description: "Coulomb's law, electric field, Gauss's theorem", topics: ["Electric charge", "Coulomb's law", "Electric field", "Gauss's theorem"], difficulty: "medium", estimatedTime: 60, isCompleted: false, progress: 0 },
  { id: "phy-2", subjectId: "physics", name: "Electrostatic Potential and Capacitance", nameHindi: "स्थिरवैद्युत विभव और धारिता", number: 2, description: "Potential, capacitors, dielectrics", topics: ["Electric potential", "Equipotential surfaces", "Capacitors", "Dielectrics"], difficulty: "medium", estimatedTime: 65, isCompleted: false, progress: 0 },
  { id: "phy-3", subjectId: "physics", name: "Current Electricity", nameHindi: "विद्युत धारा", number: 3, description: "Ohm's law, Kirchhoff's laws, Wheatstone bridge", topics: ["Ohm's law", "Kirchhoff's laws", "Wheatstone bridge", "Potentiometer"], difficulty: "medium", estimatedTime: 60, isCompleted: false, progress: 0 },
  { id: "phy-4", subjectId: "physics", name: "Moving Charges and Magnetism", nameHindi: "गतिमान आवेश और चुंबकत्व", number: 4, description: "Biot-Savart law, Ampere's law, moving coil galvanometer", topics: ["Biot-Savart law", "Ampere's law", "Galvanometer", "Cyclotron"], difficulty: "hard", estimatedTime: 70, isCompleted: false, progress: 0 },
  { id: "phy-5", subjectId: "physics", name: "Magnetism and Matter", nameHindi: "चुंबकत्व और द्रव्य", number: 5, description: "Bar magnet, Earth's magnetism, magnetic materials", topics: ["Bar magnet", "Earth's magnetism", "Magnetic materials", "Hysteresis"], difficulty: "medium", estimatedTime: 50, isCompleted: false, progress: 0 },
  { id: "phy-6", subjectId: "physics", name: "Electromagnetic Induction", nameHindi: "विद्युत चुंबकीय प्रेरण", number: 6, description: "Faraday's law, Lenz's law, self and mutual induction", topics: ["Faraday's law", "Lenz's law", "Self induction", "Mutual induction"], difficulty: "hard", estimatedTime: 70, isCompleted: false, progress: 0 },
  { id: "phy-7", subjectId: "physics", name: "Alternating Current", nameHindi: "प्रत्यावर्ती धारा", number: 7, description: "AC circuits, resonance, transformer", topics: ["AC voltage", "RLC circuits", "Resonance", "Transformer"], difficulty: "hard", estimatedTime: 65, isCompleted: false, progress: 0 },
  { id: "phy-8", subjectId: "physics", name: "Electromagnetic Waves", nameHindi: "विद्युत चुंबकीय तरंगें", number: 8, description: "EM wave spectrum, properties, applications", topics: ["EM wave characteristics", "Spectrum", "Applications", "Displacement current"], difficulty: "easy", estimatedTime: 40, isCompleted: false, progress: 0 },
  { id: "phy-9", subjectId: "physics", name: "Ray Optics and Optical Instruments", nameHindi: "किरण प्रकाशिकी और प्रकाशिकी यंत्र", number: 9, description: "Reflection, refraction, lenses, microscopes", topics: ["Reflection", "Refraction", "Lenses", "Microscopes", "Telescopes"], difficulty: "medium", estimatedTime: 65, isCompleted: false, progress: 0 },
  { id: "phy-10", subjectId: "physics", name: "Wave Optics", nameHindi: "तरंग प्रकाशिकी", number: 10, description: "Interference, diffraction, polarization", topics: ["Interference", "Diffraction", "Polarization", "Young's experiment"], difficulty: "hard", estimatedTime: 70, isCompleted: false, progress: 0 },
  { id: "phy-11", subjectId: "physics", name: "Dual Nature of Radiation and Matter", nameHindi: "विकिरण और द्रव्य की द्वैत प्रकृति", number: 11, description: "Photoelectric effect, de Broglie waves", topics: ["Photoelectric effect", "Einstein's equation", "de Broglie waves", "Davisson-Germer experiment"], difficulty: "hard", estimatedTime: 60, isCompleted: false, progress: 0 },
  { id: "phy-12", subjectId: "physics", name: "Atoms", nameHindi: "परमाणु", number: 12, description: "Rutherford model, Bohr model, spectra", topics: ["Rutherford model", "Bohr model", "Hydrogen spectrum", "X-rays"], difficulty: "medium", estimatedTime: 55, isCompleted: false, progress: 0 },
  { id: "phy-13", subjectId: "physics", name: "Nuclei", nameHindi: "नाभिक", number: 13, description: "Nuclear structure, radioactivity, nuclear reactions", topics: ["Nuclear structure", "Radioactivity", "Half life", "Nuclear fission", "Nuclear fusion"], difficulty: "medium", estimatedTime: 55, isCompleted: false, progress: 0 },
  { id: "phy-14", subjectId: "physics", name: "Semiconductor Electronics", nameHindi: "अर्धचालक इलेक्ट्रॉनिकी", number: 14, description: "Diodes, transistors, logic gates", topics: ["Semiconductors", "Diodes", "Transistors", "Logic gates"], difficulty: "medium", estimatedTime: 60, isCompleted: false, progress: 0 },
  { id: "phy-15", subjectId: "physics", name: "Communication Systems", nameHindi: "संचार व्यवस्था", number: 15, description: "Modulation, demodulation, communication channels", topics: ["Modulation", "Demodulation", "AM", "FM", "Digital communication"], difficulty: "easy", estimatedTime: 40, isCompleted: false, progress: 0 },
]

export const CHEMISTRY_CHAPTERS: Chapter[] = [
  { id: "chem-1", subjectId: "chemistry", name: "The Solid State", nameHindi: "ठोस अवस्था", number: 1, description: "Crystal structures, packing, defects", topics: ["Crystal systems", "Packing efficiency", "Defects", "Semiconductors"], difficulty: "medium", estimatedTime: 55, isCompleted: false, progress: 0 },
  { id: "chem-2", subjectId: "chemistry", name: "Solutions", nameHindi: "विलयन", number: 2, description: "Concentration, colligative properties, Raoult's law", topics: ["Concentration terms", "Raoult's law", "Colligative properties", "Abnormal molar mass"], difficulty: "medium", estimatedTime: 60, isCompleted: false, progress: 0 },
  { id: "chem-3", subjectId: "chemistry", name: "Electrochemistry", nameHindi: "विद्युत रसायन", number: 3, description: "Cells, electrode potential, Nernst equation", topics: ["Electrochemical cells", "Nernst equation", "Conductivity", "Batteries"], difficulty: "hard", estimatedTime: 70, isCompleted: false, progress: 0 },
  { id: "chem-4", subjectId: "chemistry", name: "Chemical Kinetics", nameHindi: "रासायनिक बलगतिकी", number: 4, description: "Rate laws, order, activation energy, catalysis", topics: ["Rate of reaction", "Rate laws", "Order", "Activation energy", "Catalysts"], difficulty: "hard", estimatedTime: 70, isCompleted: false, progress: 0 },
  { id: "chem-5", subjectId: "chemistry", name: "Surface Chemistry", nameHindi: "पृष्ठ रसायन", number: 5, description: "Adsorption, catalysis, colloids", topics: ["Adsorption", "Catalysis", "Colloids", "Emulsions"], difficulty: "easy", estimatedTime: 45, isCompleted: false, progress: 0 },
  { id: "chem-6", subjectId: "chemistry", name: "General Principles and Processes of Isolation of Elements", nameHindi: "तत्वों के निष्कर्षण के सामान्य सिद्धांत और प्रक्रम", number: 6, description: "Metallurgy, concentration, reduction, refining", topics: ["Concentration", "Reduction", "Refining", "Ellingham diagram"], difficulty: "medium", estimatedTime: 55, isCompleted: false, progress: 0 },
  { id: "chem-7", subjectId: "chemistry", name: "The p-Block Elements", nameHindi: "p-ब्लॉक के तत्व", number: 7, description: "Group 15, 16, 17, 18 elements and compounds", topics: ["Nitrogen family", "Oxygen family", "Halogens", "Noble gases"], difficulty: "medium", estimatedTime: 65, isCompleted: false, progress: 0 },
  { id: "chem-8", subjectId: "chemistry", name: "The d-and f-Block Elements", nameHindi: "d- और f-ब्लॉक के तत्व", number: 8, description: "Transition metals, lanthanides, actinides", topics: ["Transition metals", "Lanthanides", "Actinides", "Coordination compounds"], difficulty: "hard", estimatedTime: 65, isCompleted: false, progress: 0 },
  { id: "chem-9", subjectId: "chemistry", name: "Coordination Compounds", nameHindi: "सहसंयोजन यौगिक", number: 9, description: "Werner's theory, bonding, isomerism, applications", topics: ["Werner's theory", "VBT", "CFT", "Isomerism"], difficulty: "hard", estimatedTime: 70, isCompleted: false, progress: 0 },
  { id: "chem-10", subjectId: "chemistry", name: "Haloalkanes and Haloarenes", nameHindi: "हैलोएल्केन और हैलोएरीन", number: 10, description: "Preparation, reactions, uses of halogen compounds", topics: ["Preparation", "SN1/SN2", "Elimination", "Uses"], difficulty: "medium", estimatedTime: 60, isCompleted: false, progress: 0 },
  { id: "chem-11", subjectId: "chemistry", name: "Alcohols, Phenols and Ethers", nameHindi: "एल्कोहॉल, फीनॉल और ईथर", number: 11, description: "Preparation, properties, reactions", topics: ["Alcohols", "Phenols", "Ethers", "Reactions"], difficulty: "medium", estimatedTime: 60, isCompleted: false, progress: 0 },
  { id: "chem-12", subjectId: "chemistry", name: "Aldehydes, Ketones and Carboxylic Acids", nameHindi: "एल्डिहाइड, कीटोन और कार्बोक्सिलिक अम्ल", number: 12, description: "Preparation, properties, reactions, tests", topics: ["Aldehydes", "Ketones", "Carboxylic acids", "Tests"], difficulty: "hard", estimatedTime: 70, isCompleted: false, progress: 0 },
  { id: "chem-13", subjectId: "chemistry", name: "Amines", nameHindi: "एमीन", number: 13, description: "Classification, preparation, reactions, tests", topics: ["Classification", "Preparation", "Reactions", "Diazonium salts"], difficulty: "medium", estimatedTime: 55, isCompleted: false, progress: 0 },
  { id: "chem-14", subjectId: "chemistry", name: "Biomolecules", nameHindi: "जैव अणु", number: 14, description: "Carbohydrates, proteins, vitamins, nucleic acids", topics: ["Carbohydrates", "Proteins", "Vitamins", "Nucleic acids"], difficulty: "easy", estimatedTime: 50, isCompleted: false, progress: 0 },
  { id: "chem-15", subjectId: "chemistry", name: "Polymers", nameHindi: "बहुलक", number: 15, description: "Types, polymerization, uses of polymers", topics: ["Addition polymerization", "Condensation", "Types", "Uses"], difficulty: "easy", estimatedTime: 45, isCompleted: false, progress: 0 },
  { id: "chem-16", subjectId: "chemistry", name: "Chemistry in Everyday Life", nameHindi: "दैनिक जीवन में रसायन", number: 16, description: "Drugs, food additives, cleansing agents", topics: ["Drugs", "Food additives", "Soaps", "Detergents"], difficulty: "easy", estimatedTime: 40, isCompleted: false, progress: 0 },
]

export const HINDI_CHAPTERS: Chapter[] = [
  { id: "hin-1", subjectId: "hindi", name: "आरोह - गद्य खंड", nameHindi: "आरोह - गद्य खंड", number: 1, description: "Prose section from Aaroh textbook", topics: ["Essays", "Stories", "Biographies"], difficulty: "medium", estimatedTime: 50, isCompleted: false, progress: 0 },
  { id: "hin-2", subjectId: "hindi", name: "आरोह - पद्य खंड", nameHindi: "आरोह - पद्य खंड", number: 2, description: "Poetry section from Aaroh textbook", topics: ["Poems", "Ghazals", "Dohas"], difficulty: "medium", estimatedTime: 45, isCompleted: false, progress: 0 },
  { id: "hin-3", subjectId: "hindi", name: "वितान - गद्य खंड", nameHindi: "वितान - गद्य खंड", number: 3, description: "Prose section from Vitan textbook", topics: ["Essays", "Stories"], difficulty: "medium", estimatedTime: 45, isCompleted: false, progress: 0 },
  { id: "hin-4", subjectId: "hindi", name: "वितान - पद्य खंड", nameHindi: "वितान - पद्य खंड", number: 4, description: "Poetry section from Vitan textbook", topics: ["Poems", "Kavitas"], difficulty: "medium", estimatedTime: 40, isCompleted: false, progress: 0 },
  { id: "hin-5", subjectId: "hindi", name: "हिंदी व्याकरण", nameHindi: "हिंदी व्याकरण", number: 5, description: "Grammar - Alankar, Muhavare, Samas, Sandhi", topics: ["Alankar", "Muhavare", "Samas", "Sandhi", "Vachan", "Karak"], difficulty: "easy", estimatedTime: 60, isCompleted: false, progress: 0 },
  { id: "hin-6", subjectId: "hindi", name: "पत्र लेखन", nameHindi: "पत्र लेखन", number: 6, description: "Letter writing - formal and informal", topics: ["Formal letters", "Informal letters", "Applications"], difficulty: "easy", estimatedTime: 35, isCompleted: false, progress: 0 },
  { id: "hin-7", subjectId: "hindi", name: "निबंध लेखन", nameHindi: "निबंध लेखन", number: 7, description: "Essay writing on various topics", topics: ["Social issues", "Science", "Environment"], difficulty: "medium", estimatedTime: 40, isCompleted: false, progress: 0 },
]

export const ENGLISH_CHAPTERS: Chapter[] = [
  { id: "eng-1", subjectId: "english", name: "Flamingo - Prose", nameHindi: "फ्लेमिंगो - गद्य", number: 1, description: "Prose chapters from Flamingo textbook", topics: ["The Last Lesson", "Lost Spring", "Deep Water", "The Rattrap"], difficulty: "medium", estimatedTime: 55, isCompleted: false, progress: 0 },
  { id: "eng-2", subjectId: "english", name: "Flamingo - Poetry", nameHindi: "फ्लेमिंगो - पद्य", number: 2, description: "Poetry chapters from Flamingo textbook", topics: ["My Mother at Sixty-Six", "An Elementary School", "Keeping Quiet", "A Thing of Beauty"], difficulty: "medium", estimatedTime: 50, isCompleted: false, progress: 0 },
  { id: "eng-3", subjectId: "english", name: "Vistas - Supplementary", nameHindi: "विस्टास - पूरक", number: 3, description: "Supplementary reader Vistas", topics: ["The Third Level", "The Enemy", "Should Wizard Hit Mommy", "On the Face of It"], difficulty: "medium", estimatedTime: 50, isCompleted: false, progress: 0 },
  { id: "eng-4", subjectId: "english", name: "Writing Skills", nameHindi: "लेखन कौशल", number: 4, description: "Notice, poster, letter, article, speech writing", topics: ["Notice", "Poster", "Formal letter", "Article", "Speech"], difficulty: "easy", estimatedTime: 45, isCompleted: false, progress: 0 },
  { id: "eng-5", subjectId: "english", name: "Grammar", nameHindi: "व्याकरण", number: 5, description: "Tenses, modals, active-passive, reported speech", topics: ["Tenses", "Modals", "Active-Passive", "Reported speech", "Error correction"], difficulty: "easy", estimatedTime: 50, isCompleted: false, progress: 0 },
  { id: "eng-6", subjectId: "english", name: "Literature - Long Reading", nameHindi: "साहित्य - दीर्घ पठन", number: 6, description: "Novel study and character analysis", topics: ["Character analysis", "Themes", "Plot summary"], difficulty: "medium", estimatedTime: 60, isCompleted: false, progress: 0 },
]

export const ALL_CHAPTERS: Record<string, Chapter[]> = {
  biology: BIOLOGY_CHAPTERS,
  physics: PHYSICS_CHAPTERS,
  chemistry: CHEMISTRY_CHAPTERS,
  hindi: HINDI_CHAPTERS,
  english: ENGLISH_CHAPTERS,
}

export const AGENT_CONFIGS: Record<string, AgentConfig> = {
  biology: {
    subjectId: "biology",
    name: "Bhaiya (Biology Tutor)",
    personality: "Warm, patient elder brother who loves nature and farming. Uses simple Hindi and connects everything to daily life.",
    teachingStyle: "Start with real-life examples (body, farming, food), then explain the concept, then show diagrams, then give memory tricks. Never use big words without explaining.",
    examples: [
      "DNA ko samjho jaise family tree - baap se beta ko features transfer hote hain",
      "Cell jaise ek factory hai - har part ka kaam alag hai",
      "Photosynthesis jaise kitchen hai - plant khana banata hai sunlight se",
    ],
    analogies: [
      "Mitochondria = Power house = Ghar ka inverter",
      "Cell membrane = Security guard = Ghar ka darwaza",
      "Nucleus = Boss = Ghar ka mukhiya",
      "Ribosome = Chef = Rasoi wala",
    ],
    memoryTricks: [
      "MRS GREN - Movement, Respiration, Sensitivity, Growth, Reproduction, Excretion, Nutrition",
      "KINGDOM - Keep Pond Clean Or Frogs Get Sick (Kingdom, Phylum, Class, Order, Family, Genus, Species)",
    ],
    systemPrompt: `You are Bhaiya, a caring elder brother teaching Biology to a weak Class 12 student. You teach like you're sitting next to him.

RULES:
1. Always explain in SIMPLE HINDI first, then English if needed
2. Use daily life examples - body, farming, food, family
3. For every concept: give a story or analogy first
4. Explain diagrams in detail - describe what each part does
5. Highlight NCERT important lines
6. Break down scientific words: "Mitochondria matlab 'mito' = thread, 'chondria' = granule"
7. After every concept ask: "Samajh aaya ya aur simple example doon?"
8. Never assume prior knowledge - teach from ZERO
9. Use emojis to make it fun 🧬🌱🦠
10. Keep sentences short. Max 15 words per sentence.

TEACHING SEQUENCE:
1. Real-life hook (2 min)
2. Concept explanation with analogy (5 min)
3. Diagram description (3 min)
4. NCERT important lines (2 min)
5. Memory trick (1 min)
6. Check understanding (1 min)`,
  },
  physics: {
    subjectId: "physics",
    name: "Bhaiya (Physics Tutor)",
    personality: "Cool, practical elder brother who loves bikes, cricket, and gadgets. Makes physics feel like magic tricks.",
    teachingStyle: "NEVER start with formulas. Sequence: Real-life situation → What happens? → Why? → Concept → Visualization → Formula → Solved example with bike/cricket/mobile/fan/train examples.",
    examples: [
      "Current electricity samjho jaise paani ka pipe - jitna pressure (voltage) zyada, utna paani (current) tez",
      "Magnetism jaise bike ka horn - button dabao, horn baje - cause and effect",
      "Lens jaise chashma - mota lens = mota chashma = zyada power",
    ],
    analogies: [
      "Voltage = Water pressure = Motor ka zor",
      "Current = Water flow = Pipe me paani ki speed",
      "Resistance = Pipe width = Chhota pipe = zyada resistance",
      "Capacitor = Water tank = Paani store karta hai",
    ],
    memoryTricks: [
      "V=IR - Voltage Is Resistance (V=IR)",
      "Fleming's Left Hand - FBI - Force, B-field, Current",
      "Fleming's Right Hand - MRI - Motion, Field, Induced current",
      "LCR - Ladki (L) Chhota (C) Rasta (R)",
    ],
    systemPrompt: `You are Bhaiya, a cool elder brother teaching Physics to a weak Class 12 student. You make physics feel like everyday magic.

CRITICAL RULE - NEVER START WITH FORMULA:
1. Start with bike/cricket/mobile/fan/train example
2. Ask "Kabhi notice kiya?"
3. Explain what happens and WHY
4. Draw mental picture
5. THEN give formula
6. Solve with numbers from daily life

LANGUAGE:
- Simple Hindi first, English terms in brackets
- "Electric field matlab woh zameen jahan charge paida hota hai"
- Break formulas: "F = qE matlab Force = charge × Electric field"

ENGAGEMENT:
- After every concept: "Samajh aaya? Cricket me kaise hota hai ye?"
- Use emojis: ⚡🔌🚲🏏
- Make student feel smart: "Tu already ye janta hai, bas formal name sikhna hai"

COST SAVING:
- Be concise but complete
- Use bullet points
- One concept at a time`,
  },
  chemistry: {
    subjectId: "chemistry",
    name: "Bhaiya (Chemistry Tutor)",
    personality: "Clever elder brother who loves cooking and kitchen experiments. Turns chemistry into kitchen recipes.",
    teachingStyle: "Reactions = Recipes. Mechanisms = Step-by-step cooking. Numericals = Bill calculation. Make memory shortcuts for everything.",
    examples: [
      "Chemical reaction jaise cooking recipe - ingredients (reactants) → process (conditions) → dish (products)",
      "Catalyst jaise mom - reaction tez karti hai, khud khatam nahi hoti",
      "pH scale jaise teekha-mitha - 7 = normal, <7 = teekha (acid), >7 = kadwa (base)",
    ],
    analogies: [
      "Chemical bond = Dosti - strong bond = close friends, weak bond = Facebook friends",
      "Electron = Paise - atoms want to donate/gain to become stable (8 paise = rich/stable)",
      "Activation energy = Ghar se nikalne ki himmat - catalyst kam karta hai",
      "Equilibrium = Tug of war - equal forces, no movement",
    ],
    memoryTricks: [
      "OIL RIG - Oxidation Is Loss, Reduction Is Gain (of electrons)",
      "LEO says GER - Lose Electrons Oxidation, Gain Electrons Reduction",
      "AN OX - Anode Oxidation, RED CAT - Reduction Cathode",
      "SPONCH - Six main elements: Sulfur, Phosphorus, Oxygen, Nitrogen, Carbon, Hydrogen",
    ],
    systemPrompt: `You are Bhaiya, a clever elder brother teaching Chemistry to a weak Class 12 student using kitchen and daily life analogies.

TEACHING METHOD:
1. Every reaction = Cooking recipe
   - Reactants = Ingredients
   - Conditions = Temperature/Gas
   - Products = Final dish
   - Catalyst = Mom's magic touch

2. Step-by-step mechanisms:
   - Arrow pushing = "Ye electron idhar gaya"
   - Intermediates = "Beech ka maal"
   - Final product = "Final dish ready"

3. Numericals:
   - Pehle formula likh
   - Values rakh
   - Step-by-step solve
   - Units check karo

4. Memory shortcuts for EVERYTHING:
   - OIL RIG, LEO GER, AN OX RED CAT
   - Create new ones on the spot

LANGUAGE:
- Hindi + English terms
- "Ye compound jaise masala mix hai - alag alag cheezein milke naya taste"
- After every reaction: "Samajh aaya? Ghar me kaise bana sakte hain?"

Be concise, use emojis 🧪⚗️🍳, make it fun!`,
  },
  hindi: {
    subjectId: "hindi",
    name: "Bhaiya (Hindi Tutor)",
    personality: "Cultured elder brother who loves stories, poetry, and explaining deep meanings simply.",
    teachingStyle: "Line-by-line explanation. First literal meaning, then hidden meaning, then writer's intention. Connect to student's life.",
    examples: [
      "'Madhushala' matlab sharab ka ghar nahi, zindagi ka ghar hai - har line me philosophy chhupi hai",
      "Premchand ke characters jaise hamare ghar ke log - real, flawed, but human",
    ],
    analogies: [
      "Kavita ka bhav = Song ka music - words alag hain, feeling same",
      "Ras = Juice of poetry - wo feeling jo padhne ke baad aati hai",
      "Alankar = Makeup of poetry - chehra sundar lagta hai",
    ],
    memoryTricks: [
      "Ras ke 9 types - SHRINGAR (love), HASYA (comedy), KARUN (sad), RAUDRA (angry), VEER (brave), BHAYANAK (fear), BIBHATSA (disgust), ADHBHUT (wonder), SHANT (peace)",
      "Alankar: Upma (tulna), Rupak (sadrisya), Utpreksha (kalpana)",
    ],
    systemPrompt: `You are Bhaiya, a cultured elder brother teaching Hindi to a Class 12 student. You love stories and explain deep meanings simply.

TEACHING STYLE:
1. Line-by-line explanation:
   - Pehle shabdo ka arth (word meaning)
   - Phir vakya ka arth (sentence meaning)
   - Phir chhupa hua arth (hidden meaning)
   - Phir lekhak ka intention (writer's message)

2. For Poetry:
   - Pehle padhao (make student read)
   - Phir explain karo line by line
   - Bhav (emotion) samjhao
   - Alankar identify karo
   - Life se connect karo

3. For Grammar:
   - Rule simple words me
   - 3 examples immediately
   - Common mistakes batayo
   - Practice karwao

4. For Writing:
   - Format dikhao
   - Sample likhke do
   - Important phrases do
   - Practice topics do

LANGUAGE:
- Pure Hindi + simple explanations
- Difficult words ka arth alag se
- "Ye shabd matlab..."
- After every paragraph: "Samajh aaya? Apni zindagi me kaise judega ye?"

Use emojis 📖✍️🎭, make it emotional and relatable.`,
  },
  english: {
    subjectId: "english",
    name: "Bhaiya (English Tutor)",
    personality: "Friendly elder brother who learned English from movies and songs. Makes literature feel like Netflix series.",
    teachingStyle: "Story first, then characters like real people, then vocabulary, then important questions. Compare to movies and real life.",
    examples: [
      "The Last Lesson = Last day at school before teacher leaves - jaise aapka favorite teacher transfer ho raha ho",
      "Lost Spring = Child labor - jaise bachche school jaane ke bajaye kaam karein",
      "Deep Water = Fear of water - jaise aapko kisi cheez se dar lagta ho",
    ],
    analogies: [
      "Character = Real person with flaws - jaise aapke dost",
      "Theme = Movie ka message - jaise 3 Idiots me 'follow your passion'",
      "Symbolism = Hidden meaning - jaise red color = danger",
      "Irony = Ulta - jo socha tha, hua ulta",
    ],
    memoryTricks: [
      "Literary devices: SIMILE = Like/as, METAPHOR = Direct comparison, PERSONIFICATION = Human traits to non-human, ALLITERATION = Same sound repetition",
      "Essay structure: INTRO (hook) → BODY (3 points) → CONCLUSION (summary + opinion)",
    ],
    systemPrompt: `You are Bhaiya, a friendly elder brother teaching English to a Class 12 student. You compare literature to movies and real life.

TEACHING SEQUENCE:
1. Story summary (like Netflix recap):
   - "Ye story hai ek ladke ki..."
   - 2-3 minute summary in Hindi
   - "Jaise movie me hota hai..."

2. Characters (like real people):
   - Name + personality + role
   - "Ye character jaise aapka dost hai jo..."
   - Character map banao

3. Vocabulary:
   - Difficult words list
   - Hindi meaning
   - Sentence me use karo
   - Daily life me kaise use hoga

4. Important questions:
   - Board ke perspective se
   - Answer format batao
   - Key points highlight karo
   - Practice karwao

5. Grammar:
   - Rule simple Hindi me
   - Error spot karwao
   - Transformation practice

LANGUAGE:
- Hindi + English mix
- "Ye word matlab Hindi me..."
- "English me aise kehte hain..."
- After every lesson: "Samajh aaya? Kisi movie se compare karoon?"

Use emojis 📝🎬📚, make it relatable and fun.`,
  },
}

export function getChaptersBySubject(subjectId: string): Chapter[] {
  return ALL_CHAPTERS[subjectId] || []
}

export function getAgentConfig(subjectId: string): AgentConfig {
  return AGENT_CONFIGS[subjectId] || AGENT_CONFIGS.biology
}

export function getSubjectById(subjectId: string): Subject | undefined {
  return SUBJECTS.find((s) => s.id === subjectId)
}

export function getChapterById(chapterId: string): Chapter | undefined {
  for (const chapters of Object.values(ALL_CHAPTERS)) {
    const chapter = chapters.find((c) => c.id === chapterId)
    if (chapter) return chapter
  }
  return undefined
}
