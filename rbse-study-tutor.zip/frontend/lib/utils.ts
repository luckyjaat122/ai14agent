import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatTime(minutes: number): string {
  if (minutes < 60) return `${minutes} min`
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`
}

export function getSubjectColor(subjectId: string): string {
  const colors: Record<string, string> = {
    biology: "bg-biology text-biology-dark",
    physics: "bg-physics text-physics-dark",
    chemistry: "bg-chemistry text-chemistry-dark",
    hindi: "bg-hindi text-hindi-dark",
    english: "bg-english text-english-dark",
  }
  return colors[subjectId] || "bg-gray-100 text-gray-800"
}

export function getSubjectGradient(subjectId: string): string {
  const gradients: Record<string, string> = {
    biology: "from-green-50 to-emerald-50 border-green-200",
    physics: "from-blue-50 to-indigo-50 border-blue-200",
    chemistry: "from-amber-50 to-orange-50 border-amber-200",
    hindi: "from-pink-50 to-rose-50 border-pink-200",
    english: "from-violet-50 to-purple-50 border-violet-200",
  }
  return gradients[subjectId] || "from-gray-50 to-slate-50 border-gray-200"
}

export function getSubjectIcon(subjectId: string): string {
  const icons: Record<string, string> = {
    biology: "🧬",
    physics: "⚡",
    chemistry: "⚗️",
    hindi: "📖",
    english: "📝",
  }
  return icons[subjectId] || "📚"
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
}

export function debounce<T extends (...args: any[]) => void>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout
  return (...args: Parameters<T>) => {
    clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), wait)
  }
}

export function simplifyForChild(text: string): string {
  // Simple text simplification - in production, use Claude for this
  return text
    .replace(/utilize/g, "use")
    .replace(/demonstrate/g, "show")
    .replace(/approximately/g, "about")
    .replace(/sufficient/g, "enough")
    .replace(/necessitate/g, "need")
    .replace(/facilitate/g, "help")
    .replace(/subsequently/g, "then")
    .replace(/nevertheless/g, "but")
    .replace(/consequently/g, "so")
    .replace(/furthermore/g, "also")
}

export function chunkArray<T>(array: T[], size: number): T[][] {
  const chunks: T[][] = []
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size))
  }
  return chunks
}
