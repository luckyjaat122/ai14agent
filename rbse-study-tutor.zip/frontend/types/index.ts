export interface Subject {
  id: string
  name: string
  nameHindi: string
  color: string
  icon: string
  description: string
  descriptionHindi: string
  totalChapters: number
  completedChapters: number
}

export interface Chapter {
  id: string
  subjectId: string
  name: string
  nameHindi: string
  number: number
  description: string
  topics: string[]
  difficulty: "easy" | "medium" | "hard"
  estimatedTime: number // minutes
  isCompleted: boolean
  progress: number
}

export interface TeachingSession {
  id: string
  chapterId: string
  subjectId: string
  currentPart: number
  totalParts: number
  messages: TeachingMessage[]
  startedAt: string
  status: "active" | "paused" | "completed"
}

export interface TeachingMessage {
  id: string
  role: "tutor" | "student"
  content: string
  contentHindi?: string
  type: "introduction" | "concept" | "example" | "memory" | "revision" | "test" | "doubt" | "general"
  timestamp: string
  hasDiagram?: boolean
  diagramUrl?: string
  isSimplified?: boolean
}

export interface Flashcard {
  id: string
  chapterId: string
  subjectId: string
  front: string
  back: string
  frontHindi?: string
  backHindi?: string
  difficulty: "easy" | "medium" | "hard"
  isMastered: boolean
  reviewCount: number
  lastReviewed: string | null
}

export interface Quiz {
  id: string
  chapterId: string
  subjectId: string
  questions: QuizQuestion[]
  totalScore: number
  userScore: number
  completedAt: string | null
}

export interface QuizQuestion {
  id: string
  question: string
  questionHindi?: string
  options: string[]
  optionsHindi?: string[]
  correctAnswer: number
  explanation: string
  explanationHindi?: string
  difficulty: "easy" | "medium" | "hard"
  userAnswer?: number
  isCorrect?: boolean
  marks: number
}

export interface RevisionNote {
  id: string
  chapterId: string
  subjectId: string
  type: "one-page" | "last-night" | "important-questions" | "formula-sheet"
  content: string
  contentHindi?: string
  generatedAt: string
}

export interface DoubtMessage {
  id: string
  question: string
  answer: string
  answerHindi?: string
  subjectId: string
  chapterId?: string
  timestamp: string
  isResolved: boolean
  simplifiedCount: number
}

export interface PDFUpload {
  id: string
  subjectId: string
  fileName: string
  fileSize: number
  uploadStatus: "uploading" | "processing" | "completed" | "error"
  chaptersDetected: string[]
  progress: number
  uploadedAt: string
}

export interface UserProgress {
  subjectId: string
  totalChapters: number
  completedChapters: number
  totalStudyTime: number // minutes
  quizAverage: number
  flashcardsMastered: number
  streakDays: number
  lastStudied: string
}

export interface AgentConfig {
  subjectId: string
  name: string
  personality: string
  teachingStyle: string
  examples: string[]
  analogies: string[]
  memoryTricks: string[]
  systemPrompt: string
}

export type TeachingPart = 
  | "introduction" 
  | "concept" 
  | "memory" 
  | "revision" 
  | "testing"

export interface RAGChunk {
  id: string
  text: string
  metadata: {
    source: string
    chapter: string
    page: number
    subject: string
  }
  score: number
}
