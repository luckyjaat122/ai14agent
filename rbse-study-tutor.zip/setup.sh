#!/bin/bash

echo "🚀 Setting up RBSE Study Tutor..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 18+ first."
    exit 1
fi

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3.9+ first."
    exit 1
fi

echo "✅ Node.js and Python found"

# Setup Frontend
echo "📦 Setting up Frontend..."
cd frontend
npm install
if [ ! -f .env.local ]; then
    cp .env.local.example .env.local
    echo "⚠️  Please update .env.local with your Clerk and Supabase credentials"
fi
cd ..

# Setup Backend
echo "🐍 Setting up Backend..."
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
if [ ! -f .env ]; then
    cp .env.example .env
    echo "⚠️  Please update .env with your Anthropic API key"
fi
cd ..

echo ""
echo "✅ Setup complete!"
echo ""
echo "To start the application:"
echo "  1. Terminal 1: cd frontend && npm run dev"
echo "  2. Terminal 2: cd backend && source venv/bin/activate && python main.py"
echo ""
echo "Don't forget to:"
echo "  - Update frontend/.env.local with Clerk keys"
echo "  - Update backend/.env with Anthropic API key"
echo ""
echo "Happy Learning! 📚"
